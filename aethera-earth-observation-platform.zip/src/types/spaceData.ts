export type DomainType = 'agriculture' | 'insurance' | 'defense' | 'climate';

export type SensorType = 
  | 'optical_ultra_hd' // 0.3m VNIR
  | 'optical_multispectral' // 0.8m 8-band
  | 'sar_x_band' // 0.5m Spotlight / 3m Stripmap Quad-Pol
  | 'sar_l_band' // 2.5m InSAR Coherence
  | 'hyperspectral_tir'; // 240 bands + 40m Thermal

export interface Satellite {
  id: string;
  name: string;
  noradId: number;
  sensorType: SensorType;
  orbitType: 'SSO' | 'LEO';
  altitudeKm: number;
  inclinationDeg: number;
  velocityKmS: number;
  periodMinutes: number;
  swathWidthKm: number;
  status: 'nominal' | 'downlinking' | 'imaging' | 'slewing';
  onboardStorageUsedGb: number;
  onboardStorageMaxGb: number;
  batteryPercent: number;
  color: string;
  // Current dynamic state
  currentLat: number;
  currentLng: number;
  trueAnomaly: number; // degrees
}

export interface GroundStation {
  id: string;
  name: string;
  code: string;
  country: string;
  lat: number;
  lng: number;
  elevationM: number;
  dishes: {
    id: string;
    diameterM: number;
    bands: ('S' | 'X' | 'Ka')[];
    maxDataRateMbps: number;
    currentAzimuth: number; // 0-360
    currentElevation: number; // 0-90
    status: 'tracking' | 'idle' | 'calibrating' | 'stowed';
    assignedSatelliteId?: string;
  }[];
}

export interface ContactPass {
  id: string;
  satelliteId: string;
  satelliteName: string;
  groundStationId: string;
  groundStationName: string;
  dishId: string;
  aosUtc: string; // Acquisition of Signal
  losUtc: string; // Loss of Signal
  durationSeconds: number;
  maxElevationDeg: number;
  frequencyBand: 'X' | 'Ka' | 'S';
  dataVolumeGb: number;
  status: 'active' | 'scheduled' | 'completed' | 'queued';
  snrDb: number;
}

export interface TargetFeature {
  id: string;
  type: 'vessel' | 'flood_zone' | 'crop_parcel' | 'methane_source' | 'deforestation_patch';
  label: string;
  confidence: number;
  lat: number;
  lng: number;
  metadata: Record<string, string | number>;
}

export interface EarthScene {
  id: string;
  title: string;
  domain: DomainType;
  locationName: string;
  country: string;
  lat: number;
  lng: number;
  acquisitionDate: string;
  sensor: SensorType;
  resolutionM: number;
  cloudCoverPercent: number;
  incidenceAngleDeg?: number;
  polarization?: 'VV' | 'VH' | 'VV+VH' | 'Quad-Pol (HH+HV+VV+VH)';
  summary: string;
  opticalImage: string;
  sarImage?: string;
  features: TargetFeature[];
  radiometrics: {
    meanNdvi?: number;
    sarMeanBackscatterDb?: number;
    inundationAreaSqKm?: number;
    methaneFluxKgHr?: number;
    vesselsDetected?: number;
    darkVesselsCount?: number;
    coherenceLossPercent?: number;
  };
  bandPresets: {
    id: string;
    label: string;
    description: string;
    type: 'optical' | 'sar' | 'composite';
  }[];
}

export interface TaskingRequest {
  id: string;
  customer: string;
  title: string;
  domain: DomainType;
  sensor: SensorType;
  priority: 'routine' | 'priority_24h' | 'flash_charter_6h';
  targetLat: number;
  targetLng: number;
  targetName: string;
  requestedDate: string;
  predictedPassUtc: string;
  predictedDownlinkStation: string;
  status: 'pending' | 'accepted' | 'uplinked' | 'acquired' | 'downlinked';
  costCredits: number;
}
