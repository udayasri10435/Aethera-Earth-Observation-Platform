/**
 * Orbital calculation helpers for Sun-Synchronous and Low Earth Orbits
 */

const EARTH_RADIUS_KM = 6371;

/**
 * Propagate orbital coordinates (Lat, Lng) from epoch, inclination, altitude, and period.
 */
export function calculateSatellitePosition(
  epochMs: number,
  altitudeKm: number,
  inclinationDeg: number,
  periodMinutes: number,
  initialPhaseDeg: number = 0
): { lat: number; lng: number; altitudeKm: number; velocityKmS: number } {
  const elapsedMinutes = epochMs / (1000 * 60);
  const orbitalFraction = ((elapsedMinutes % periodMinutes) / periodMinutes);
  const meanAnomalyRad = (orbitalFraction * 2 * Math.PI) + (initialPhaseDeg * Math.PI / 180);

  const incRad = (inclinationDeg * Math.PI) / 180;

  // Simplified circular orbit projection
  // Lat: arcsin(sin(i) * sin(u))
  const sinLat = Math.sin(incRad) * Math.sin(meanAnomalyRad);
  const latRad = Math.asin(sinLat);
  const lat = (latRad * 180) / Math.PI;

  // Lng: atan2(cos(i)*sin(u), cos(u)) - earth_rotation
  const y = Math.cos(incRad) * Math.sin(meanAnomalyRad);
  const x = Math.cos(meanAnomalyRad);
  const rawLngRad = Math.atan2(y, x);

  // Earth rotates ~360 deg every 1440 minutes (24 hours) = 0.25 deg/min
  const earthRotationDeg = (elapsedMinutes * (360 / 1440)) % 360;
  let lng = ((rawLngRad * 180) / Math.PI) - earthRotationDeg;

  // Wrap to -180 to 180
  lng = ((lng + 180) % 360) - 180;
  if (lng < -180) lng += 360;

  // Orbital velocity v = sqrt(mu / (R + h))
  const mu = 398600.4418; // km^3/s^2
  const velocityKmS = Math.sqrt(mu / (EARTH_RADIUS_KM + altitudeKm));

  return {
    lat,
    lng,
    altitudeKm,
    velocityKmS: Number(velocityKmS.toFixed(2)),
  };
}

/**
 * Calculate Azimuth and Elevation look angles from a ground station to a satellite
 */
export function calculateLookAngle(
  stationLat: number,
  stationLng: number,
  stationAltM: number,
  satLat: number,
  satLng: number,
  satAltKm: number
): { azimuthDeg: number; elevationDeg: number; rangeKm: number; inView: boolean } {
  const phi1 = (stationLat * Math.PI) / 180;
  const lam1 = (stationLng * Math.PI) / 180;
  const phi2 = (satLat * Math.PI) / 180;
  const lam2 = (satLng * Math.PI) / 180;

  const R = EARTH_RADIUS_KM + (stationAltM / 1000);
  const Rsat = EARTH_RADIUS_KM + satAltKm;

  // Ground station ECEF
  const x1 = R * Math.cos(phi1) * Math.cos(lam1);
  const y1 = R * Math.cos(phi1) * Math.sin(lam1);
  const z1 = R * Math.sin(phi1);

  // Satellite ECEF
  const x2 = Rsat * Math.cos(phi2) * Math.cos(lam2);
  const y2 = Rsat * Math.cos(phi2) * Math.sin(lam2);
  const z2 = Rsat * Math.sin(phi2);

  // Relative vector
  const dx = x2 - x1;
  const dy = y2 - y1;
  const dz = z2 - z1;
  const rangeKm = Math.sqrt(dx * dx + dy * dy + dz * dz);

  // Topocentric ENU coordinates
  const east = -Math.sin(lam1) * dx + Math.cos(lam1) * dy;
  const north = -Math.sin(phi1) * Math.cos(lam1) * dx - Math.sin(phi1) * Math.sin(lam1) * dy + Math.cos(phi1) * dz;
  const up = Math.cos(phi1) * Math.cos(lam1) * dx + Math.cos(phi1) * Math.sin(lam1) * dy + Math.sin(phi1) * dz;

  const horizDist = Math.sqrt(east * east + north * north);
  let elevationDeg = (Math.atan2(up, horizDist) * 180) / Math.PI;

  let azimuthDeg = (Math.atan2(east, north) * 180) / Math.PI;
  if (azimuthDeg < 0) azimuthDeg += 360;

  // Horizon mask threshold 5 degrees
  const inView = elevationDeg >= 5;

  return {
    azimuthDeg: Number(azimuthDeg.toFixed(1)),
    elevationDeg: Number(elevationDeg.toFixed(1)),
    rangeKm: Number(rangeKm.toFixed(1)),
    inView,
  };
}

/**
 * Generate ground track polyline points for an orbital trajectory
 */
export function generateGroundTrack(
  baseEpochMs: number,
  altitudeKm: number,
  inclinationDeg: number,
  periodMinutes: number,
  initialPhaseDeg: number,
  spanMinutes: number = 95,
  stepMinutes: number = 2
): { lat: number; lng: number }[] {
  const points: { lat: number; lng: number }[] = [];
  for (let m = -spanMinutes / 2; m <= spanMinutes / 2; m += stepMinutes) {
    const timeMs = baseEpochMs + m * 60 * 1000;
    const pos = calculateSatellitePosition(timeMs, altitudeKm, inclinationDeg, periodMinutes, initialPhaseDeg);
    points.push({ lat: pos.lat, lng: pos.lng });
  }
  return points;
}
