import React, { useState } from 'react';
import { 
  INITIAL_SATELLITES, 
  GROUND_STATIONS, 
  EARTH_SCENES, 
  INITIAL_PASSES, 
  INITIAL_TASKINGS 
} from './data/mockSpaceData';
import { 
  Satellite, 
  GroundStation, 
  EarthScene, 
  ContactPass, 
  TaskingRequest, 
  DomainType 
} from './types/spaceData';
import { Header, ActiveTab } from './components/Header';
import { ImageryStudio } from './components/ImageryStudio';
import { TacticalOrbitMap } from './components/TacticalOrbitMap';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { GroundStationScheduler } from './components/GroundStationScheduler';
import { TaskingConsole } from './components/TaskingConsole';
import { 
  Globe2, 
  Eye, 
  Radio, 
  BarChart3, 
  Zap, 
  ShieldAlert, 
  Droplets, 
  Sprout, 
  Wind,
  CheckCircle2,
  HardDrive,
  Cpu,
  Activity
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('studio');

  // Application state
  const [satellites, setSatellites] = useState<Satellite[]>(INITIAL_SATELLITES);
  const [groundStations, setGroundStations] = useState<GroundStation[]>(GROUND_STATIONS);
  const [scenes, setScenes] = useState<EarthScene[]>(EARTH_SCENES);
  const [activeScene, setActiveScene] = useState<EarthScene>(EARTH_SCENES[0]);
  const [passes, setPasses] = useState<ContactPass[]>(INITIAL_PASSES);
  const [taskings, setTaskings] = useState<TaskingRequest[]>(INITIAL_TASKINGS);

  // Selected telemetry entities
  const [selectedSatelliteId, setSelectedSatelliteId] = useState<string>(INITIAL_SATELLITES[0].id);
  const [selectedStationId, setSelectedStationId] = useState<string>(GROUND_STATIONS[0].id);
  const [analyticsDomain, setAnalyticsDomain] = useState<DomainType>('defense');

  // Count active downlinks
  const activeDownlinks = passes.filter((p) => p.status === 'active').length;

  // Handlers for cross-module interactions
  const handleSelectSceneFromMap = (scene: EarthScene) => {
    setActiveScene(scene);
    setActiveTab('studio');
  };

  const handleSelectStationFromMap = (station: GroundStation) => {
    setSelectedStationId(station.id);
    setActiveTab('ground_stations');
  };

  const handleAddPass = (newPass: ContactPass) => {
    setPasses((prev) => [newPass, ...prev]);
  };

  const handleAddTasking = (newTask: TaskingRequest) => {
    setTaskings((prev) => [newTask, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Telemetry Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        activeDownlinkCount={activeDownlinks}
      />

      {/* Main Operational Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Constellation Telemetry Ticker Ribbon */}
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {satellites.map((sat) => {
            const isSelected = selectedSatelliteId === sat.id;
            return (
              <button
                key={sat.id}
                onClick={() => {
                  setSelectedSatelliteId(sat.id);
                  if (activeTab !== 'orbit_map') setActiveTab('orbit_map');
                }}
                className={`p-3 rounded-lg border text-left transition-all ${
                  isSelected
                    ? 'bg-slate-900 border-sky-500/70 shadow-lg shadow-sky-500/10'
                    : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-200">
                    {sat.name.split(' ')[0]}
                  </span>
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: sat.color }}
                  />
                </div>
                <div className="mt-1 text-[11px] text-slate-400 font-mono flex items-center justify-between">
                  <span>Alt: {sat.altitudeKm}km</span>
                  <span className="text-emerald-400">{sat.batteryPercent}%</span>
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-0.5 truncate uppercase">
                  {sat.status} · {sat.onboardStorageUsedGb}GB
                </div>
              </button>
            );
          })}
        </section>

        {/* Tab 1: Flagship Imagery & SAR Studio */}
        {activeTab === 'studio' && (
          <ImageryStudio
            scenes={scenes}
            activeScene={activeScene}
            onSelectScene={setActiveScene}
          />
        )}

        {/* Tab 2: Global Tactical Orbit Map */}
        {activeTab === 'orbit_map' && (
          <div className="space-y-6">
            <TacticalOrbitMap
              satellites={satellites}
              groundStations={groundStations}
              scenes={scenes}
              activePasses={passes}
              selectedSatelliteId={selectedSatelliteId}
              onSelectSatellite={setSelectedSatelliteId}
              onSelectScene={handleSelectSceneFromMap}
              onSelectGroundStation={handleSelectStationFromMap}
            />

            {/* Orbit Parameters Deck */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
              <div className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-2">
                <Activity className="w-4 h-4 text-sky-400" />
                <span>Active Constellation Orbits & Ephemeris Telemetry</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-medium">
                      <th className="pb-2">Satellite Vehicle</th>
                      <th className="pb-2">NORAD ID</th>
                      <th className="pb-2">Orbit / Altitude</th>
                      <th className="pb-2">Inclination</th>
                      <th className="pb-2">Velocity</th>
                      <th className="pb-2">Swath Width</th>
                      <th className="pb-2">Payload Mode</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850">
                    {satellites.map((sat) => (
                      <tr key={sat.id} className="hover:bg-slate-950/40">
                        <td className="py-2.5 font-semibold text-slate-200 flex items-center gap-2">
                          <span
                            className="w-2 h-2 rounded-full inline-block"
                            style={{ backgroundColor: sat.color }}
                          />
                          {sat.name}
                        </td>
                        <td className="py-2.5 font-mono text-slate-400">{sat.noradId}</td>
                        <td className="py-2.5 font-mono text-slate-300">
                          {sat.orbitType} · {sat.altitudeKm} km
                        </td>
                        <td className="py-2.5 font-mono text-slate-300">{sat.inclinationDeg}°</td>
                        <td className="py-2.5 font-mono text-slate-300">{sat.velocityKmS} km/s</td>
                        <td className="py-2.5 font-mono text-sky-400">{sat.swathWidthKm} km</td>
                        <td className="py-2.5 font-mono text-[11px] text-slate-400 uppercase">
                          {sat.sensorType.replace(/_/g, ' ')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Domain Analytics */}
        {activeTab === 'analytics' && (
          <AnalyticsPanel
            currentDomain={analyticsDomain}
            onSelectDomain={setAnalyticsDomain}
            scenes={scenes}
            onSelectScene={setActiveScene}
          />
        )}

        {/* Tab 4: Ground Station Scheduler */}
        {activeTab === 'ground_stations' && (
          <GroundStationScheduler
            groundStations={groundStations}
            passes={passes}
            satellites={satellites}
            onAddPass={handleAddPass}
            selectedStationId={selectedStationId}
            onSelectStation={setSelectedStationId}
          />
        )}

        {/* Tab 5: Tasking Hub */}
        {activeTab === 'tasking' && (
          <TaskingConsole
            taskings={taskings}
            onAddTasking={handleAddTasking}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400 font-mono">AETHERA SPACE DATA</span>
            <span>·</span>
            <span>Sub-meter Optical & Quad-Pol SAR Synthetic Aperture Radar</span>
          </div>

          <div className="flex items-center gap-4 font-mono text-[11px]">
            <span>Active Sensors: 5 SSO</span>
            <span>·</span>
            <span>Ground Apertures: 11 Dishes</span>
            <span>·</span>
            <span>Calibrated Radiometry: CEOS Level-2A</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
