import React, { useState } from 'react';
import { GroundStation, ContactPass, Satellite } from '../types/spaceData';
import { 
  Radio, 
  Calendar, 
  Clock, 
  Signal, 
  HardDrive, 
  CheckCircle2, 
  Plus, 
  ArrowUpRight, 
  Sliders, 
  Activity, 
  Satellite as SatelliteIcon,
  Compass,
  AlertTriangle
} from 'lucide-react';

interface GroundStationSchedulerProps {
  groundStations: GroundStation[];
  passes: ContactPass[];
  satellites: Satellite[];
  onAddPass: (pass: ContactPass) => void;
  selectedStationId?: string;
  onSelectStation: (stationId: string) => void;
}

export const GroundStationScheduler: React.FC<GroundStationSchedulerProps> = ({
  groundStations,
  passes,
  satellites,
  onAddPass,
  selectedStationId,
  onSelectStation,
}) => {
  const [activeStationId, setActiveStationId] = useState<string>(
    selectedStationId || groundStations[0]?.id || ''
  );

  // New Pass Scheduling Modal state
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [selectedSatForPass, setSelectedSatForPass] = useState<string>(satellites[0]?.id || '');
  const [selectedGsForPass, setSelectedGsForPass] = useState<string>(groundStations[0]?.id || '');
  const [selectedBand, setSelectedBand] = useState<'X' | 'Ka' | 'S'>('Ka');
  const [passScheduledSuccess, setPassScheduledSuccess] = useState<boolean>(false);

  const currentStation = groundStations.find((g) => g.id === activeStationId) || groundStations[0];
  const activePass = passes.find((p) => p.status === 'active');

  const handleCreatePass = (e: React.FormEvent) => {
    e.preventDefault();
    const sat = satellites.find((s) => s.id === selectedSatForPass);
    const gs = groundStations.find((g) => g.id === selectedGsForPass);
    if (!sat || !gs) return;

    const dish = gs.dishes[0];
    const newPass: ContactPass = {
      id: `pass-${Date.now()}`,
      satelliteId: sat.id,
      satelliteName: sat.name,
      groundStationId: gs.id,
      groundStationName: `${gs.name.split(' ')[0]} (${gs.code})`,
      dishId: dish ? dish.id : 'ANT-01',
      aosUtc: '17:15:20 UTC',
      losUtc: '17:26:45 UTC',
      durationSeconds: 685,
      maxElevationDeg: 72.4,
      frequencyBand: selectedBand,
      dataVolumeGb: selectedBand === 'Ka' ? 145.0 : 82.5,
      status: 'scheduled',
      snrDb: 17.8,
    };

    onAddPass(newPass);
    setPassScheduledSuccess(true);
    setTimeout(() => {
      setPassScheduledSuccess(false);
      setIsModalOpen(false);
    }, 1500);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Radio className="w-5 h-5 text-sky-400" />
            <span>Global Ground Station Network & Pass Scheduler</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Coordinated aperture management across 6 high-latitude and equatorial dish clusters for continuous payload downlink.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 py-2 px-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold rounded-lg text-xs transition-colors shadow-lg shadow-sky-500/10 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule Downlink Pass</span>
        </button>
      </div>

      {/* Ground Station Cluster Selector */}
      <div className="mt-6 flex flex-wrap gap-2">
        {groundStations.map((gs) => {
          const isSelected = gs.id === activeStationId;
          const hasActive = passes.some((p) => p.groundStationId === gs.id && p.status === 'active');

          return (
            <button
              key={gs.id}
              onClick={() => {
                setActiveStationId(gs.id);
                onSelectStation(gs.id);
              }}
              className={`flex items-center gap-2.5 px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                isSelected
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/50 shadow-md'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <div
                className={`w-2 h-2 rounded-full ${
                  hasActive ? 'bg-amber-400 animate-ping' : isSelected ? 'bg-sky-400' : 'bg-slate-600'
                }`}
              />
              <span className="font-semibold text-slate-200">{gs.code}</span>
              <span className="text-slate-400">· {gs.country.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Main Grid: Left Dish & Skyplot, Right Upcoming Passes */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Active Dish Steering & Skyplot */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-sm font-semibold text-slate-200">{currentStation.name}</div>
              <div className="text-[11px] text-slate-400 font-mono">
                Lat: {currentStation.lat.toFixed(2)}° · Lng: {currentStation.lng.toFixed(2)}° · Alt: {currentStation.elevationM}m
              </div>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-sky-400 border border-slate-700">
              {currentStation.dishes.length} Antennas
            </span>
          </div>

          {/* Polar Skyplot Canvas simulation */}
          <div className="relative w-full aspect-square max-w-[280px] mx-auto my-3 bg-slate-900 rounded-full border border-slate-800 flex items-center justify-center overflow-hidden">
            {/* Concentric Elevation Rings (30°, 60°, Horizon 0°) */}
            <div className="absolute w-[80%] h-[80%] rounded-full border border-slate-800"></div>
            <div className="absolute w-[50%] h-[50%] rounded-full border border-slate-800"></div>
            <div className="absolute w-[20%] h-[20%] rounded-full border border-slate-800"></div>

            {/* Crosshairs N-S, E-W */}
            <div className="absolute w-full h-px bg-slate-800"></div>
            <div className="absolute h-full w-px bg-slate-800"></div>

            {/* Direction Labels */}
            <span className="absolute top-2 text-[10px] font-mono text-slate-500 font-bold">N</span>
            <span className="absolute bottom-2 text-[10px] font-mono text-slate-500 font-bold">S</span>
            <span className="absolute right-2 text-[10px] font-mono text-slate-500 font-bold">E</span>
            <span className="absolute left-2 text-[10px] font-mono text-slate-500 font-bold">W</span>

            {/* Simulated Satellite Trajectory Arc */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <path
                d="M 50 200 Q 140 40 230 180"
                fill="none"
                stroke="rgba(56, 189, 248, 0.4)"
                strokeWidth="2"
                strokeDasharray="4 4"
              />
              {/* Current Tracking Pointer */}
              <circle cx="150" cy="70" r="5" fill="#f59e0b" />
              <line x1="140" y1="140" x2="150" y2="70" stroke="#f59e0b" strokeWidth="1.5" />
            </svg>

            {/* Center Zenith Mark */}
            <div className="w-1.5 h-1.5 rounded-full bg-sky-400"></div>
          </div>

          {/* Dish Telemetry List */}
          <div className="mt-4 space-y-3">
            {currentStation.dishes.map((dish) => (
              <div key={dish.id} className="p-3 bg-slate-900/70 border border-slate-800/80 rounded-md text-xs">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-sky-400" />
                    <span>{dish.id} ({dish.diameterM}m Dish)</span>
                  </div>
                  <span
                    className={`font-mono text-[10px] uppercase px-1.5 py-0.5 rounded ${
                      dish.status === 'tracking'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {dish.status}
                  </span>
                </div>

                <div className="mt-2 grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400">
                  <div>Azimuth: <span className="text-slate-200 tabular-nums">{dish.currentAzimuth.toFixed(1)}°</span></div>
                  <div>Elevation: <span className="text-slate-200 tabular-nums">{dish.currentElevation.toFixed(1)}°</span></div>
                  <div>Bands: <span className="text-sky-400">{dish.bands.join('/')}</span></div>
                  <div>Max Rate: <span className="text-emerald-400 tabular-nums">{dish.maxDataRateMbps} Mbps</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 2 Columns: Scheduled Contact Pass Queue & Telemetry */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-sm font-semibold text-slate-200">
                Downlink Pass Queue ({passes.length} Passes Scheduled)
              </div>
              <div className="text-xs text-slate-400">
                Prioritized contact windows for SAR raw radar phase data and optical multispectral granules.
              </div>
            </div>
          </div>

          {/* Active Pass Highlight Banner */}
          {activePass && (
            <div className="mb-4 p-4 rounded-lg bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/30">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></div>
                  <span className="text-xs font-bold text-amber-300 font-mono tracking-wide">
                    DOWNLINK IN PROGRESS: {activePass.satelliteName}
                  </span>
                </div>
                <span className="text-xs font-mono text-amber-300 tabular-nums">
                  SNR: +{activePass.snrDb} dB · Rate: 2.4 Gbps
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden my-2">
                <div className="bg-amber-400 h-2 rounded-full w-[68%] transition-all"></div>
              </div>

              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Station: {activePass.groundStationName}</span>
                <span>Volume: 112.4 / {activePass.dataVolumeGb} GB</span>
                <span>AOS: {activePass.aosUtc}</span>
              </div>
            </div>
          )}

          {/* Passes Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-medium">
                  <th className="pb-2">Satellite</th>
                  <th className="pb-2">Station & Dish</th>
                  <th className="pb-2">AOS - LOS</th>
                  <th className="pb-2">Duration</th>
                  <th className="pb-2">Max El</th>
                  <th className="pb-2">Band & Volume</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {passes.map((pass) => (
                  <tr key={pass.id} className="hover:bg-slate-900/50 transition-colors">
                    <td className="py-2.5 font-semibold text-slate-200">
                      {pass.satelliteName}
                    </td>
                    <td className="py-2.5 text-slate-300 font-mono text-[11px]">
                      {pass.groundStationName} · {pass.dishId}
                    </td>
                    <td className="py-2.5 font-mono text-slate-300 text-[11px]">
                      {pass.aosUtc} - {pass.losUtc}
                    </td>
                    <td className="py-2.5 font-mono text-slate-400 tabular-nums">
                      {Math.floor(pass.durationSeconds / 60)}m {pass.durationSeconds % 60}s
                    </td>
                    <td className="py-2.5 font-mono text-emerald-400 tabular-nums">
                      {pass.maxElevationDeg.toFixed(1)}°
                    </td>
                    <td className="py-2.5 font-mono text-sky-400 tabular-nums">
                      {pass.frequencyBand}-Band · {pass.dataVolumeGb} GB
                    </td>
                    <td className="py-2.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                          pass.status === 'active'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : pass.status === 'scheduled'
                            ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {pass.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal: Schedule Downlink Pass */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full shadow-2xl">
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-sky-400" />
              <span>Schedule Satellite Contact Pass</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Reserve RF spectrum and directional antenna tracking for payload dump and telemetry uplink.
            </p>

            <form onSubmit={handleCreatePass} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Target Satellite Constellation Member
                </label>
                <select
                  value={selectedSatForPass}
                  onChange={(e) => setSelectedSatForPass(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                >
                  {satellites.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.sensorType}) - NORAD #{s.noradId}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Downlink Ground Station
                </label>
                <select
                  value={selectedGsForPass}
                  onChange={(e) => setSelectedGsForPass(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                >
                  {groundStations.map((gs) => (
                    <option key={gs.id} value={gs.id}>
                      {gs.name} ({gs.country})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Downlink Frequency Channel
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Ka', 'X', 'S'] as const).map((band) => (
                    <button
                      type="button"
                      key={band}
                      onClick={() => setSelectedBand(band)}
                      className={`py-2 px-3 rounded-lg text-xs font-mono font-medium transition-colors ${
                        selectedBand === band
                          ? 'bg-sky-500 text-slate-950 font-bold'
                          : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {band}-Band {band === 'Ka' ? '(2.4 Gbps)' : band === 'X' ? '(1.2 Gbps)' : '(TT&C)'}
                    </button>
                  ))}
                </div>
              </div>

              {passScheduledSuccess ? (
                <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-lg text-xs text-emerald-300 flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Contact pass confirmed & orbital azimuth trajectory uploaded.</span>
                </div>
              ) : (
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs text-slate-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    Confirm & Reserve Aperture
                  </button>
                </div>
              )}
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
