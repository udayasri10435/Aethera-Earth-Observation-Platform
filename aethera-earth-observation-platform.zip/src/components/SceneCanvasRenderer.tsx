import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { EarthScene, TargetFeature } from '../types/spaceData';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Layers, 
  Eye, 
  Sliders, 
  Maximize2, 
  Crosshair, 
  Download,
  AlertTriangle,
  Ship,
  Droplets,
  Sprout,
  Wind
} from 'lucide-react';

interface SceneCanvasRendererProps {
  scene: EarthScene;
  activeBandPresetId: string;
  isSwipeMode: boolean;
  swipePositionPercent: number; // 0 to 100
  onSwipeChange: (val: number) => void;
  showVectors: boolean;
  onSelectFeature?: (feature: TargetFeature) => void;
  selectedFeatureId?: string;
}

export const SceneCanvasRenderer: React.FC<SceneCanvasRendererProps> = ({
  scene,
  activeBandPresetId,
  isSwipeMode,
  swipePositionPercent,
  onSwipeChange,
  showVectors,
  onSelectFeature,
  selectedFeatureId,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Pan and zoom state
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Mouse hover radiometric probe
  const [hoverPixel, setHoverPixel] = useState<{
    x: number;
    y: number;
    lat: number;
    lng: number;
    valueLabel: string;
    feature?: TargetFeature;
  } | null>(null);

  // Histogram stretch
  const [contrastBoost, setContrastBoost] = useState<number>(1.1);
  const [brightness, setBrightness] = useState<number>(1.0);

  // Reset viewport
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Convert canvas pixel to geo coordinates
  const pixelToGeo = useCallback((px: number, py: number, width: number, height: number) => {
    // 0.05 degree span centered at scene.lat, scene.lng
    const latSpan = 0.04;
    const lngSpan = 0.06;
    const lat = scene.lat + (0.5 - py / height) * latSpan;
    const lng = scene.lng + (px / width - 0.5) * lngSpan;
    return { lat, lng };
  }, [scene.lat, scene.lng]);

  // Main procedural Earth observation raster rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    // Apply pan and zoom
    ctx.translate(width / 2 + pan.x, height / 2 + pan.y);
    ctx.scale(zoom, zoom);
    ctx.translate(-width / 2, -height / 2);

    // Render layers: Optical / SAR / Composite
    // We render into offscreen buffers or procedural math for extreme realism
    const renderSceneRaster = (isSarPass: boolean, clipWidth?: number) => {
      ctx.save();
      if (clipWidth !== undefined) {
        ctx.beginPath();
        if (isSarPass) {
          ctx.rect(clipWidth, 0, width - clipWidth, height);
        } else {
          ctx.rect(0, 0, clipWidth, height);
        }
        ctx.clip();
      }

      // Generate Domain-specific base texture
      if (scene.domain === 'defense') {
        // Sea / Reef / Dark Vessel environment
        renderDefenseScene(ctx, width, height, isSarPass, activeBandPresetId, scene);
      } else if (scene.domain === 'insurance') {
        // Flood / Storm cloud / Inundation
        renderInsuranceFloodScene(ctx, width, height, isSarPass, activeBandPresetId, scene);
      } else if (scene.domain === 'agriculture') {
        // Crop parcels, NDVI grid, soil moisture
        renderAgricultureScene(ctx, width, height, isSarPass, activeBandPresetId, scene);
      } else {
        // Climate: Methane plume or Thwaites glacier InSAR
        renderClimateScene(ctx, width, height, isSarPass, activeBandPresetId, scene);
      }

      ctx.restore();
    };

    if (isSwipeMode) {
      const splitX = (swipePositionPercent / 100) * width;
      // Optical on the left
      renderSceneRaster(false, splitX);
      // SAR on the right
      renderSceneRaster(true, splitX);

      // Draw swipe divider line
      ctx.save();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2 / zoom;
      ctx.beginPath();
      ctx.moveTo(splitX, 0);
      ctx.lineTo(splitX, height);
      ctx.stroke();

      // Divider handle icon
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(splitX, height / 2, 14 / zoom, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2 / zoom;
      ctx.stroke();
      ctx.restore();
    } else {
      const isSarActive = activeBandPresetId.startsWith('sar') || activeBandPresetId === 'insar_fringes' || activeBandPresetId === 'flood_mask';
      renderSceneRaster(isSarActive);
    }

    // Render Vector Overlays (Features, Bounding Boxes, Polygons)
    if (showVectors) {
      scene.features.forEach((feat) => {
        // Map feature lat/lng to canvas x/y
        const latSpan = 0.04;
        const lngSpan = 0.06;
        const fx = ((feat.lng - scene.lng) / lngSpan + 0.5) * width;
        const fy = (0.5 - (feat.lat - scene.lat) / latSpan) * height;

        const isSelected = selectedFeatureId === feat.id;

        ctx.save();
        if (feat.type === 'vessel') {
          const isDark = String(feat.metadata['AIS Status']).includes('DARK');
          ctx.strokeStyle = isDark ? '#ef4444' : '#10b981';
          ctx.lineWidth = isSelected ? 3 / zoom : 1.5 / zoom;
          ctx.fillStyle = isDark ? 'rgba(239, 68, 68, 0.2)' : 'rgba(16, 185, 129, 0.15)';

          // Bounding box with corner brackets
          const bw = 54;
          const bh = 28;
          ctx.strokeRect(fx - bw / 2, fy - bh / 2, bw, bh);
          ctx.fillRect(fx - bw / 2, fy - bh / 2, bw, bh);

          // Heading vector
          ctx.beginPath();
          ctx.moveTo(fx, fy);
          ctx.lineTo(fx - 24, fy - 18);
          ctx.stroke();

          // Label
          ctx.fillStyle = '#ffffff';
          ctx.font = `600 ${Math.max(10, 11 / zoom)}px "JetBrains Mono", monospace`;
          ctx.fillText(feat.label, fx - bw / 2, fy - bh / 2 - 6);
          if (isDark) {
            ctx.fillStyle = '#f87171';
            ctx.fillText('AIS DARK [CFAR +34dB]', fx - bw / 2, fy + bh / 2 + 14);
          }
        } else if (feat.type === 'flood_zone') {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = isSelected ? 3 / zoom : 1.8 / zoom;
          ctx.fillStyle = 'rgba(56, 189, 248, 0.28)';

          // Irregular polygon for flood inundation
          ctx.beginPath();
          ctx.ellipse(fx, fy, 48, 32, Math.PI / 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = '#bae6fd';
          ctx.font = `600 ${Math.max(10, 11 / zoom)}px "JetBrains Mono", monospace`;
          ctx.fillText(feat.label, fx - 40, fy - 36);
        } else if (feat.type === 'crop_parcel') {
          ctx.strokeStyle = isSelected ? '#a3e635' : '#4ade80';
          ctx.lineWidth = isSelected ? 3 / zoom : 1.5 / zoom;
          ctx.fillStyle = 'rgba(74, 222, 128, 0.15)';
          ctx.strokeRect(fx - 45, fy - 35, 90, 70);
          ctx.fillRect(fx - 45, fy - 35, 90, 70);

          ctx.fillStyle = '#ffffff';
          ctx.font = `600 ${Math.max(10, 11 / zoom)}px "JetBrains Mono", monospace`;
          ctx.fillText(feat.label, fx - 42, fy - 38);
        } else if (feat.type === 'methane_source') {
          // Plume beacon
          ctx.strokeStyle = '#fbbf24';
          ctx.lineWidth = 2 / zoom;
          ctx.beginPath();
          ctx.arc(fx, fy, 16, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = 'rgba(245, 158, 11, 0.3)';
          ctx.beginPath();
          ctx.arc(fx, fy, 8, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#fef08a';
          ctx.font = `600 ${Math.max(10, 11 / zoom)}px "JetBrains Mono", monospace`;
          ctx.fillText(feat.label, fx + 20, fy + 4);
        }
        ctx.restore();
      });
    }

    // Grid coordinates & North Arrow
    renderGeospatialOverlays(ctx, width, height, zoom, scene);

    ctx.restore();
  }, [
    scene, 
    activeBandPresetId, 
    isSwipeMode, 
    swipePositionPercent, 
    showVectors, 
    selectedFeatureId, 
    zoom, 
    pan, 
    contrastBoost, 
    brightness
  ]);

  // Handle Dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }

    // Compute radiometric probe under mouse
    const width = canvasRef.current.width;
    const height = canvasRef.current.height;

    // Invert zoom & pan
    const cx = width / 2;
    const cy = height / 2;
    const localX = (mouseX - cx - pan.x) / zoom + cx;
    const localY = (mouseY - cy - pan.y) / zoom + cy;

    if (localX >= 0 && localX <= width && localY >= 0 && localY <= height) {
      const geo = pixelToGeo(localX, localY, width, height);

      // Find nearby feature
      const latSpan = 0.04;
      const lngSpan = 0.06;
      const hoveredFeature = scene.features.find((f) => {
        const fx = ((f.lng - scene.lng) / lngSpan + 0.5) * width;
        const fy = (0.5 - (f.lat - scene.lat) / latSpan) * height;
        return Math.hypot(fx - localX, fy - localY) < 30;
      });

      let valLabel = '';
      if (scene.domain === 'agriculture') {
        const pseudoNdvi = (0.5 + Math.sin(localX / 30) * 0.2 + Math.cos(localY / 40) * 0.2).toFixed(2);
        valLabel = `NDVI: ${pseudoNdvi} · Refl B8: 48.2%`;
      } else if (scene.domain === 'insurance') {
        const isWater = localY > height * 0.35 && localY < height * 0.75;
        valLabel = isWater ? 'SAR Backscatter: -24.8 dB (Water)' : 'SAR Backscatter: -8.1 dB (Urban)';
      } else if (scene.domain === 'defense') {
        valLabel = hoveredFeature ? 'RCS Target: +34.2 dBm² (Metal)' : 'Sea Clutter: -16.4 dB';
      } else {
        valLabel = 'CH4 Col: 1,920 ppb · SWIR: 0.18';
      }

      setHoverPixel({
        x: mouseX,
        y: mouseY,
        lat: Number(geo.lat.toFixed(5)),
        lng: Number(geo.lng.toFixed(5)),
        valueLabel: valLabel,
        feature: hoveredFeature,
      });
    } else {
      setHoverPixel(null);
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 1.15 : 0.87;
    setZoom((prev) => Math.min(8, Math.max(0.5, prev * delta)));
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-[620px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-2xl select-none"
    >
      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={1000}
        height={620}
        className="w-full h-full cursor-crosshair block"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => {
          setIsDragging(false);
          setHoverPixel(null);
        }}
        onWheel={handleWheel}
      />

      {/* Top Left: Scene Metadata & Coordinate HUD */}
      <div className="absolute top-3 left-3 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-lg p-3 text-xs shadow-lg max-w-sm pointer-events-none">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="font-semibold text-slate-100">{scene.title}</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
          <span>{scene.sensor.toUpperCase().replace(/_/g, ' ')}</span>
          <span>·</span>
          <span>Res: {scene.resolutionM}m</span>
          <span>·</span>
          <span>{scene.acquisitionDate}</span>
        </div>
        {scene.polarization && (
          <div className="text-amber-400 font-mono text-[11px] mt-1">
            Pol: {scene.polarization} · Inc: {scene.incidenceAngleDeg}°
          </div>
        )}
      </div>

      {/* Swipe Mode Top Banner */}
      {isSwipeMode && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur border border-sky-500/40 px-4 py-1.5 rounded-full flex items-center gap-3 text-xs shadow-xl">
          <span className="text-sky-300 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-sky-400"></span>
            OPTICAL (LEFT)
          </span>
          <span className="text-slate-500 font-mono">VS</span>
          <span className="text-amber-300 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            SAR RADAR (RIGHT)
          </span>
          <input
            type="range"
            min="5"
            max="95"
            value={swipePositionPercent}
            onChange={(e) => onSwipeChange(Number(e.target.value))}
            className="w-24 accent-sky-400 cursor-pointer"
          />
        </div>
      )}

      {/* Top Right: Radiometric Pixel Probe Inspector */}
      {hoverPixel && (
        <div className="absolute top-3 right-3 bg-slate-950/90 backdrop-blur-md border border-cyan-500/40 rounded-lg p-3 text-xs font-mono shadow-2xl max-w-xs pointer-events-none">
          <div className="flex items-center gap-1.5 text-cyan-400 font-semibold text-[11px] mb-1">
            <Crosshair className="w-3.5 h-3.5" />
            <span>RADIOMETRIC PROBE</span>
          </div>
          <div className="text-slate-300 text-[11px]">
            {hoverPixel.lat.toFixed(5)}°N, {hoverPixel.lng.toFixed(5)}°E
          </div>
          <div className="text-emerald-400 text-[11px] mt-0.5 font-medium">
            {hoverPixel.valueLabel}
          </div>
          {hoverPixel.feature && (
            <div className="mt-2 pt-1.5 border-t border-slate-800 text-[11px] text-amber-300">
              <div className="font-semibold">{hoverPixel.feature.label}</div>
              <div className="text-slate-400 text-[10px]">Confidence: {(hoverPixel.feature.confidence * 100).toFixed(0)}%</div>
            </div>
          )}
        </div>
      )}

      {/* Bottom Floating Control Bar */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        {/* Left: Scale & North Indicator */}
        <div className="bg-slate-950/80 backdrop-blur border border-slate-800/80 rounded-md px-3 py-1.5 text-slate-300 text-[11px] font-mono flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 bg-red-500 rounded-full inline-block"></span>
            <span className="font-semibold text-slate-200">N</span>
          </div>
          <span>·</span>
          <span>1:15,000</span>
          <span>·</span>
          <div className="flex items-center gap-1">
            <div className="w-12 h-1 bg-slate-400 border border-slate-900"></div>
            <span>500m</span>
          </div>
        </div>

        {/* Right: Zoom / Pan / Reset Controls */}
        <div className="flex items-center gap-1.5 bg-slate-950/85 backdrop-blur border border-slate-800 rounded-lg p-1 pointer-events-auto">
          <button
            onClick={() => setZoom((z) => Math.min(8, z * 1.25))}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoom((z) => Math.max(0.5, z * 0.8))}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleResetView}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors"
            title="Reset View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

// Procedural visual simulations for Earth Observation domains

function renderDefenseScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  isSar: boolean,
  preset: string,
  scene: EarthScene
) {
  if (isSar) {
    // SAR Spotlight / Pauli decomposition / Speckle radar backscatter
    // Deep dark ocean background (low radar backscatter)
    const oceanGrad = ctx.createLinearGradient(0, 0, w, h);
    oceanGrad.addColorStop(0, '#020617');
    oceanGrad.addColorStop(1, '#090d16');
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle ocean surface Bragg scattering texture
    ctx.fillStyle = 'rgba(30, 41, 59, 0.4)';
    for (let i = 0; i < 400; i++) {
      const rx = (i * 137.5) % w;
      const ry = (i * 93.1) % h;
      ctx.fillRect(rx, ry, 2, 1);
    }

    // Coral Reef atoll ring (moderate backscatter)
    ctx.strokeStyle = preset === 'pauli_decomp' ? '#10b981' : '#64748b';
    ctx.lineWidth = 14;
    ctx.beginPath();
    ctx.ellipse(w * 0.48, h * 0.52, 160, 110, 0.3, 0, Math.PI * 2);
    ctx.stroke();

    // High metal backscatter corner reflectors (ships with strong double-bounce reflections)
    scene.features.forEach((feat) => {
      const latSpan = 0.04;
      const lngSpan = 0.06;
      const fx = ((feat.lng - scene.lng) / lngSpan + 0.5) * w;
      const fy = (0.5 - (feat.lat - scene.lat) / latSpan) * h;

      // Radar Kelvin wake (V-shaped specular wake)
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx - 140, fy - 35);
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx - 130, fy + 25);
      ctx.stroke();

      // Ship superstructure bright reflection blip (double bounce)
      const isDark = String(feat.metadata['AIS Status']).includes('DARK');
      const blipColor = preset === 'pauli_decomp' ? '#ef4444' : '#ffffff';

      ctx.fillStyle = blipColor;
      ctx.shadowColor = isDark ? '#ef4444' : '#38bdf8';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.ellipse(fx, fy, 16, 5, -0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  } else {
    // Optical Ultra-HD daylight
    const seaGrad = ctx.createLinearGradient(0, 0, w, h);
    seaGrad.addColorStop(0, '#0369a1');
    seaGrad.addColorStop(1, '#0c4a6e');
    ctx.fillStyle = seaGrad;
    ctx.fillRect(0, 0, w, h);

    // Coral Reef turquoise water
    ctx.fillStyle = 'rgba(45, 212, 191, 0.45)';
    ctx.beginPath();
    ctx.ellipse(w * 0.48, h * 0.52, 160, 110, 0.3, 0, Math.PI * 2);
    ctx.fill();

    // Sand cay
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.ellipse(w * 0.46, h * 0.50, 40, 20, 0.3, 0, Math.PI * 2);
    ctx.fill();

    // Daylight ships
    scene.features.forEach((feat) => {
      const latSpan = 0.04;
      const lngSpan = 0.06;
      const fx = ((feat.lng - scene.lng) / lngSpan + 0.5) * w;
      const fy = (0.5 - (feat.lat - scene.lat) / latSpan) * h;

      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.ellipse(fx, fy, 14, 4, -0.4, 0, Math.PI * 2);
      ctx.fill();

      // White foam wake
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx - 40, fy - 10);
      ctx.stroke();
    });
  }
}

function renderInsuranceFloodScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  isSar: boolean,
  preset: string,
  scene: EarthScene
) {
  if (isSar) {
    // SAR Penetrating Radar: Cloud free!
    // Urban buildings = bright corner reflection (high backscatter -8 dB)
    // Standing calm floodwater = pitch black specular absorption (-24 dB)
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, w, h);

    // City street grid
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 4;
    for (let x = 40; x < w; x += 60) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 40; y < h; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Inundated flood zones: calm water reflects radar away into space = deep black
    ctx.fillStyle = preset === 'flood_mask' ? 'rgba(56, 189, 248, 0.65)' : '#020617';
    ctx.beginPath();
    ctx.moveTo(0, h * 0.4);
    ctx.bezierCurveTo(w * 0.3, h * 0.25, w * 0.6, h * 0.7, w, h * 0.55);
    ctx.lineTo(w, h * 0.95);
    ctx.bezierCurveTo(w * 0.7, h, w * 0.2, h * 0.75, 0, h * 0.85);
    ctx.closePath();
    ctx.fill();

    if (preset === 'flood_mask') {
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Submerged industrial blocks
    ctx.fillStyle = '#64748b';
    for (let i = 0; i < 15; i++) {
      const bx = 120 + (i * 50) % (w - 200);
      const by = 80 + (i * 70) % (h - 180);
      ctx.fillRect(bx, by, 32, 22);
    }
  } else {
    // Optical imagery during severe storm: 100% thick white/grey convective clouds!
    const cloudGrad = ctx.createLinearGradient(0, 0, w, h);
    cloudGrad.addColorStop(0, '#cbd5e1');
    cloudGrad.addColorStop(0.5, '#e2e8f0');
    cloudGrad.addColorStop(1, '#94a3b8');
    ctx.fillStyle = cloudGrad;
    ctx.fillRect(0, 0, w, h);

    // Billowing cumulus cloud texture
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    for (let i = 0; i < 20; i++) {
      ctx.beginPath();
      ctx.arc((i * 90) % w, (i * 70) % h, 70 + (i % 5) * 20, 0, Math.PI * 2);
      ctx.fill();
    }

    // Storm label
    ctx.fillStyle = '#334155';
    ctx.font = '700 16px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('OPTICAL SENSOR OBSCURED BY 100% CONVECTIVE CLOUD COVER', 40, h / 2);
    ctx.font = '500 12px "JetBrains Mono", monospace';
    ctx.fillText('Ground surface completely invisible · Switch to SAR Radar layer for penetrating flood extent', 40, h / 2 + 25);
  }
}

function renderAgricultureScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  isSar: boolean,
  preset: string,
  scene: EarthScene
) {
  // Agricultural parcel grid
  const cols = 8;
  const rows = 5;
  const pw = w / cols;
  const ph = h / rows;

  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows; r++) {
      const px = c * pw;
      const py = r * ph;

      const seed = Math.sin(c * 17 + r * 31);

      if (preset === 'ndvi_ramp') {
        // NDVI heatmap: red (stressed) to yellow to vibrant emerald green (high vigor)
        const ndvi = 0.45 + seed * 0.45;
        if (ndvi > 0.75) ctx.fillStyle = '#15803d';
        else if (ndvi > 0.6) ctx.fillStyle = '#4ade80';
        else if (ndvi > 0.45) ctx.fillStyle = '#facc15';
        else ctx.fillStyle = '#ef4444';
      } else if (preset === 'nir_color') {
        // Color Infrared (CIR): Healthy biomass appears bright red
        ctx.fillStyle = seed > 0 ? '#dc2626' : '#991b1b';
      } else if (isSar || preset === 'sar_soil') {
        // Radar soil moisture
        const moist = seed > 0.1 ? '#1e293b' : '#334155';
        ctx.fillStyle = moist;
      } else {
        // True color optical: lush green cropland
        ctx.fillStyle = seed > 0.2 ? '#22543d' : '#276749';
      }

      ctx.fillRect(px + 2, py + 2, pw - 4, ph - 4);

      // Irrigation circular pivot
      if ((c + r) % 4 === 0) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(px + pw / 2, py + ph / 2, Math.min(pw, ph) * 0.42, 0, Math.PI * 2);
        ctx.fillStyle = preset === 'ndvi_ramp' ? '#166534' : 'rgba(34, 197, 94, 0.4)';
        ctx.fill();
        ctx.restore();
      }
    }
  }

  // Field boundary borders
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 3;
  for (let c = 0; c <= cols; c++) {
    ctx.beginPath();
    ctx.moveTo(c * pw, 0);
    ctx.lineTo(c * pw, h);
    ctx.stroke();
  }
  for (let r = 0; r <= rows; r++) {
    ctx.beginPath();
    ctx.moveTo(0, r * ph);
    ctx.lineTo(w, r * ph);
    ctx.stroke();
  }
}

function renderClimateScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  isSar: boolean,
  preset: string,
  scene: EarthScene
) {
  if (scene.id === 'scene-cli-permian') {
    // Permian Basin Oil & Gas well pads + Methane Plume
    // Arid desert terrain
    ctx.fillStyle = '#451a03';
    ctx.fillRect(0, 0, w, h);

    // Well pad access roads
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, h * 0.4);
    ctx.lineTo(w, h * 0.6);
    ctx.moveTo(w * 0.4, 0);
    ctx.lineTo(w * 0.5, h);
    ctx.stroke();

    // Well pads
    ctx.fillStyle = '#92400e';
    ctx.fillRect(w * 0.38, h * 0.45, 50, 40);
    ctx.fillRect(w * 0.7, h * 0.25, 45, 35);

    // Methane plume SWIR 2.3um gas concentration heatmap
    const plumeGrad = ctx.createRadialGradient(w * 0.42, h * 0.48, 5, w * 0.75, h * 0.65, 180);
    plumeGrad.addColorStop(0, 'rgba(239, 68, 68, 0.9)'); // 1,420 kg/hr core
    plumeGrad.addColorStop(0.3, 'rgba(245, 158, 11, 0.7)');
    plumeGrad.addColorStop(0.6, 'rgba(234, 179, 8, 0.5)');
    plumeGrad.addColorStop(1, 'rgba(234, 179, 8, 0)');

    ctx.save();
    ctx.translate(w * 0.42, h * 0.48);
    ctx.rotate(0.35); // downwind plume dispersion
    ctx.fillStyle = plumeGrad;
    ctx.beginPath();
    ctx.ellipse(80, 0, 140, 45, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else {
    // Thwaites glacier InSAR rainbow fringes
    const numFringes = 12;
    for (let i = 0; i < numFringes; i++) {
      const radius = 60 + i * 28;
      ctx.strokeStyle = `hsl(${(i * 55) % 360}, 90%, 55%)`;
      ctx.lineWidth = 14;
      ctx.beginPath();
      ctx.arc(w * 0.5, h * 0.5, radius, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
}

function renderGeospatialOverlays(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  zoom: number,
  scene: EarthScene
) {
  // Hairline graticule
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 1 / zoom;
  for (let x = 100; x < w; x += 150) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 100; y < h; y += 120) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
}
