import React, { useState } from 'react';
import { EarthScene, TargetFeature, DomainType } from '../types/spaceData';
import { SceneCanvasRenderer } from './SceneCanvasRenderer';
import { 
  Layers, 
  Eye, 
  Sliders, 
  Download, 
  CheckCircle2, 
  Maximize2, 
  Crosshair, 
  Ship, 
  Droplets, 
  Sprout, 
  Wind,
  ShieldAlert,
  Info,
  ChevronDown
} from 'lucide-react';

interface ImageryStudioProps {
  scenes: EarthScene[];
  activeScene: EarthScene;
  onSelectScene: (scene: EarthScene) => void;
}

export const ImageryStudio: React.FC<ImageryStudioProps> = ({
  scenes,
  activeScene,
  onSelectScene,
}) => {
  const [activeBandPresetId, setActiveBandPresetId] = useState<string>(
    activeScene.bandPresets[0]?.id || 'natural'
  );
  const [isSwipeMode, setIsSwipeMode] = useState<boolean>(true);
  const [swipePositionPercent, setSwipePositionPercent] = useState<number>(50);
  const [showVectors, setShowVectors] = useState<boolean>(true);
  const [selectedFeature, setSelectedFeature] = useState<TargetFeature | null>(null);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // When changing scene, reset band preset to first available
  const handleSceneChange = (scene: EarthScene) => {
    onSelectScene(scene);
    setActiveBandPresetId(scene.bandPresets[0]?.id || 'natural');
    setSelectedFeature(null);
  };

  const handleExportGeoJSON = () => {
    const geojson = {
      type: 'FeatureCollection',
      properties: {
        sceneId: activeScene.id,
        sceneTitle: activeScene.title,
        sensor: activeScene.sensor,
        acquisitionDate: activeScene.acquisitionDate,
        exportedAt: new Date().toISOString(),
      },
      features: activeScene.features.map((f) => ({
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [f.lng, f.lat],
        },
        properties: {
          id: f.id,
          label: f.label,
          type: f.type,
          confidence: f.confidence,
          metadata: f.metadata,
        },
      })),
    };

    const blob = new Blob([JSON.stringify(geojson, null, 2)], { type: 'application/geo+json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeScene.id}_features.geojson`;
    a.click();
    URL.revokeObjectURL(url);

    setExportNotice('Exported GeoJSON target vectors & telemetry.');
    setTimeout(() => setExportNotice(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top Scene Selection & Quick Domain Filter Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        {/* Scene Selector */}
        <div className="flex items-center gap-3">
          <label className="text-xs font-mono text-slate-400">SELECT SCENE:</label>
          <div className="relative">
            <select
              value={activeScene.id}
              onChange={(e) => {
                const found = scenes.find((s) => s.id === e.target.value);
                if (found) handleSceneChange(found);
              }}
              className="bg-slate-950 border border-slate-800 rounded-lg pl-3 pr-8 py-2 text-xs font-semibold text-slate-200 focus:outline-none focus:border-sky-500 appearance-none cursor-pointer"
            >
              {scenes.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  [{sc.domain.toUpperCase()}] {sc.title} ({sc.locationName})
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
          </div>
        </div>

        {/* View Mode Controls: Swipe vs Single */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-950 p-1 rounded-lg border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => setIsSwipeMode(false)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                !isSwipeMode ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Single Band
            </button>
            <button
              onClick={() => setIsSwipeMode(true)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                isSwipeMode ? 'bg-sky-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Optical / SAR Split Swipe
            </button>
          </div>

          <button
            onClick={() => setShowVectors(!showVectors)}
            className={`px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
              showVectors
                ? 'bg-slate-800 text-sky-400 border-sky-500/40'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            Vector Overlays ({showVectors ? 'ON' : 'OFF'})
          </button>

          <button
            onClick={handleExportGeoJSON}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg text-xs transition-colors cursor-pointer"
            title="Download GeoJSON features"
          >
            <Download className="w-3.5 h-3.5" />
            <span>GeoJSON</span>
          </button>
        </div>
      </div>

      {exportNotice && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-2.5 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{exportNotice}</span>
        </div>
      )}

      {/* Main Interactive Studio Area */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Left 3 Columns: High-Resolution Canvas Viewer */}
        <div className="xl:col-span-3 space-y-4">
          <SceneCanvasRenderer
            scene={activeScene}
            activeBandPresetId={activeBandPresetId}
            isSwipeMode={isSwipeMode}
            swipePositionPercent={swipePositionPercent}
            onSwipeChange={setSwipePositionPercent}
            showVectors={showVectors}
            onSelectFeature={setSelectedFeature}
            selectedFeatureId={selectedFeature?.id}
          />

          {/* Spectral Band & Analytical Preset Selector Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                <Layers className="w-4 h-4 text-sky-400" />
                <span>Radiometric Band Composites & Sensor Presets</span>
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                Incidence Angle: {activeScene.incidenceAngleDeg ? `${activeScene.incidenceAngleDeg}°` : 'Nadir (0°)'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {activeScene.bandPresets.map((preset) => {
                const isSelected = activeBandPresetId === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => setActiveBandPresetId(preset.id)}
                    className={`p-3 rounded-lg text-left transition-all border ${
                      isSelected
                        ? 'bg-sky-500/15 border-sky-500/60 shadow-md'
                        : 'bg-slate-950 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-bold ${isSelected ? 'text-sky-300' : 'text-slate-200'}`}>
                        {preset.label}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 uppercase">
                        {preset.type}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {preset.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Column: Detections & Feature Inspector Panel */}
        <div className="space-y-4">
          {/* Active Feature Telemetry Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="text-xs font-bold text-slate-200 flex items-center gap-2 pb-3 border-b border-slate-800">
              <Crosshair className="w-4 h-4 text-cyan-400" />
              <span>Target Vector Telemetry</span>
            </div>

            {selectedFeature ? (
              <div className="mt-3 space-y-3">
                <div>
                  <div className="text-xs font-bold text-slate-100">{selectedFeature.label}</div>
                  <div className="text-[11px] font-mono text-cyan-400 mt-0.5">
                    Class: {selectedFeature.type} · Confidence: {(selectedFeature.confidence * 100).toFixed(0)}%
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">
                    {selectedFeature.lat.toFixed(4)}°N, {selectedFeature.lng.toFixed(4)}°E
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 space-y-2 text-xs font-mono">
                  {Object.entries(selectedFeature.metadata).map(([key, val]) => (
                    <div key={key} className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-400">{key}:</span>
                      <span className="text-slate-200 font-semibold">{String(val)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="mt-3 text-xs text-slate-400 leading-relaxed">
                Click on any vessel, flood polygon, crop parcel, or methane plume on the image to inspect sub-pixel telemetry.
              </div>
            )}
          </div>

          {/* Detections List in this Scene */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="text-xs font-bold text-slate-200 flex items-center justify-between pb-3 border-b border-slate-800">
              <span>Scene Targets ({activeScene.features.length})</span>
              <span className="text-[11px] font-mono text-slate-400 uppercase">{activeScene.domain}</span>
            </div>

            <div className="mt-3 space-y-2 max-h-[380px] overflow-y-auto pr-1">
              {activeScene.features.map((feat) => {
                const isSelected = selectedFeature?.id === feat.id;
                const isDark = String(feat.metadata['AIS Status']).includes('DARK');

                return (
                  <button
                    key={feat.id}
                    onClick={() => setSelectedFeature(feat)}
                    className={`w-full text-left p-2.5 rounded-lg border text-xs transition-all ${
                      isSelected
                        ? 'bg-sky-500/20 border-sky-500/60 shadow'
                        : 'bg-slate-950 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200 truncate max-w-[190px]">
                        {feat.label}
                      </span>
                      {isDark && (
                        <span className="text-[10px] font-mono bg-red-500/20 text-red-400 border border-red-500/30 px-1 py-0.2 rounded font-bold">
                          DARK
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 mt-1 flex items-center justify-between">
                      <span>{feat.type}</span>
                      <span className="text-emerald-400">{(feat.confidence * 100).toFixed(0)}%</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
