import React, { useRef, useEffect, useState, useMemo } from 'react';
import { Satellite, GroundStation, EarthScene, ContactPass } from '../types/spaceData';
import { calculateSatellitePosition, calculateLookAngle, generateGroundTrack } from '../utils/orbitalMath';
import { 
  Radio, 
  Satellite as SatelliteIcon, 
  MapPin, 
  Play, 
  Pause, 
  FastForward, 
  Layers, 
  Compass, 
  Shield, 
  Sprout, 
  Droplets, 
  Wind,
  Maximize2
} from 'lucide-react';

interface TacticalOrbitMapProps {
  satellites: Satellite[];
  groundStations: GroundStation[];
  scenes: EarthScene[];
  activePasses: ContactPass[];
  selectedSatelliteId: string;
  onSelectSatellite: (id: string) => void;
  onSelectScene: (scene: EarthScene) => void;
  onSelectGroundStation: (station: GroundStation) => void;
}

export const TacticalOrbitMap: React.FC<TacticalOrbitMapProps> = ({
  satellites,
  groundStations,
  scenes,
  activePasses,
  selectedSatelliteId,
  onSelectSatellite,
  onSelectScene,
  onSelectGroundStation,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Time simulation state
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(10); // 10x
  const [epochOffsetMs, setEpochOffsetMs] = useState<number>(0);
  const [hoveredEntity, setHoveredEntity] = useState<{
    type: 'sat' | 'station' | 'scene';
    title: string;
    details: string;
    x: number;
    y: number;
  } | null>(null);

  // Layer toggles
  const [showSwaths, setShowSwaths] = useState<boolean>(true);
  const [showStationCones, setShowStationCones] = useState<boolean>(true);
  const [showTracks, setShowTracks] = useState<boolean>(true);

  // Advance simulation clock
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setEpochOffsetMs((prev) => prev + 1000 * simSpeed * 0.1);
    }, 100);
    return () => clearInterval(interval);
  }, [isPlaying, simSpeed]);

  const currentSimTime = useMemo(() => {
    return new Date(Date.now() + epochOffsetMs);
  }, [epochOffsetMs]);

  // Satellite positions computed for current simulation instant
  const dynamicSatPositions = useMemo(() => {
    return satellites.map((sat) => {
      const pos = calculateSatellitePosition(
        Date.now() + epochOffsetMs,
        sat.altitudeKm,
        sat.inclinationDeg,
        sat.periodMinutes,
        sat.trueAnomaly
      );
      return {
        ...sat,
        currentLat: pos.lat,
        currentLng: pos.lng,
        velocityKmS: pos.velocityKmS,
      };
    });
  }, [satellites, epochOffsetMs]);

  // Convert (lat, lng) to canvas (x, y)
  // Equirectangular: x = (lng + 180)/360 * w, y = (90 - lat)/180 * h
  const geoToCanvas = (lat: number, lng: number, w: number, h: number) => {
    const x = ((lng + 180) / 360) * w;
    const y = ((90 - lat) / 180) * h;
    return { x, y };
  };

  // Convert canvas (x, y) to (lat, lng)
  const canvasToGeo = (x: number, y: number, w: number, h: number) => {
    const lng = (x / w) * 360 - 180;
    const lat = 90 - (y / h) * 180;
    return { lat, lng };
  };

  // Render Map Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // Deep space backdrop
    ctx.fillStyle = '#060b13';
    ctx.fillRect(0, 0, w, h);

    // Ocean fill
    ctx.fillStyle = '#0a121e';
    ctx.fillRect(0, 0, w, h);

    // Draw world landmasses procedurally
    drawSimplifiedWorldMap(ctx, w, h);

    // Draw Equirectangular Graticule
    ctx.strokeStyle = 'rgba(51, 65, 85, 0.35)';
    ctx.lineWidth = 1;
    // Latitudes: Equator, Tropics, Arctic
    const lats = [-60, -30, 0, 30, 60];
    lats.forEach((lat) => {
      const { y } = geoToCanvas(lat, 0, w, h);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    });
    // Longitudes
    for (let lng = -180; lng <= 180; lng += 45) {
      const { x } = geoToCanvas(0, lng, w, h);
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }

    // Solar Day/Night Terminator curve
    drawTerminator(ctx, w, h, currentSimTime);

    // Ground Station Cones & Radios
    groundStations.forEach((station) => {
      const { x, y } = geoToCanvas(station.lat, station.lng, w, h);

      if (showStationCones) {
        // Station visibility radius (~1800 km coverage footprint at 5° elevation)
        ctx.strokeStyle = 'rgba(14, 165, 233, 0.25)';
        ctx.fillStyle = 'rgba(14, 165, 233, 0.04)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        // Approximate pixel radius on equirectangular projection
        const radiusPx = (1800 / 40075) * w;
        ctx.ellipse(x, y, radiusPx, radiusPx * Math.cos((station.lat * Math.PI) / 180), 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      // Station Dish Marker
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(x, y, 4.5, 0, Math.PI * 2);
      ctx.fill();

      // Station Code Label
      ctx.fillStyle = '#bae6fd';
      ctx.font = '600 10px "JetBrains Mono", monospace';
      ctx.fillText(station.code, x + 8, y + 3);
    });

    // Earth Observation Target Scene Beacons
    scenes.forEach((scene) => {
      const { x, y } = geoToCanvas(scene.lat, scene.lng, w, h);

      let color = '#38bdf8';
      if (scene.domain === 'agriculture') color = '#22c55e';
      else if (scene.domain === 'insurance') color = '#38bdf8';
      else if (scene.domain === 'defense') color = '#f43f5e';
      else if (scene.domain === 'climate') color = '#eab308';

      // Pulsing target halo
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(x, y, 7, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    });

    // Active Downlink Radio Beams
    activePasses.forEach((pass) => {
      if (pass.status !== 'active') return;
      const sat = dynamicSatPositions.find((s) => s.id === pass.satelliteId);
      const gs = groundStations.find((g) => g.id === pass.groundStationId);
      if (!sat || !gs) return;

      const pSat = geoToCanvas(sat.currentLat, sat.currentLng, w, h);
      const pGs = geoToCanvas(gs.lat, gs.lng, w, h);

      // RF link line
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(pGs.x, pGs.y);
      ctx.lineTo(pSat.x, pSat.y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Radio waves ripple
      ctx.fillStyle = 'rgba(245, 158, 11, 0.4)';
      ctx.beginPath();
      ctx.arc(pGs.x, pGs.y, 10, 0, Math.PI * 2);
      ctx.fill();
    });

    // Orbital Ground Tracks for satellites
    if (showTracks) {
      dynamicSatPositions.forEach((sat) => {
        const isSelected = selectedSatelliteId === sat.id;
        const track = generateGroundTrack(
          Date.now() + epochOffsetMs,
          sat.altitudeKm,
          sat.inclinationDeg,
          sat.periodMinutes,
          sat.trueAnomaly,
          95,
          2
        );

        ctx.strokeStyle = isSelected ? sat.color : 'rgba(100, 116, 139, 0.35)';
        ctx.lineWidth = isSelected ? 2 : 1;
        ctx.beginPath();

        let lastX: number | null = null;
        track.forEach((pt) => {
          const { x, y } = geoToCanvas(pt.lat, pt.lng, w, h);
          if (lastX !== null && Math.abs(x - lastX) > w * 0.4) {
            // Anti-meridian crossing jump: break line
            ctx.stroke();
            ctx.beginPath();
          }
          ctx.lineTo(x, y);
          lastX = x;
        });
        ctx.stroke();
      });
    }

    // Satellites Markers & Swath cones
    dynamicSatPositions.forEach((sat) => {
      const { x, y } = geoToCanvas(sat.currentLat, sat.currentLng, w, h);
      const isSelected = selectedSatelliteId === sat.id;

      // Swath Footprint cone
      if (showSwaths) {
        ctx.fillStyle = isSelected ? 'rgba(56, 189, 248, 0.15)' : 'rgba(148, 163, 184, 0.08)';
        ctx.strokeStyle = isSelected ? sat.color : 'rgba(148, 163, 184, 0.25)';
        ctx.lineWidth = 1;
        const swathPx = (sat.swathWidthKm / 40075) * w * 2.5;
        ctx.beginPath();
        ctx.ellipse(x, y, swathPx, swathPx * 0.6, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      // Satellite icon / core
      ctx.fillStyle = sat.color;
      ctx.shadowColor = sat.color;
      ctx.shadowBlur = isSelected ? 12 : 6;
      ctx.beginPath();
      ctx.arc(x, y, isSelected ? 6.5 : 4.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Satellite Label
      ctx.fillStyle = isSelected ? '#ffffff' : '#94a3b8';
      ctx.font = `${isSelected ? '700' : '500'} 10px "JetBrains Mono", monospace`;
      ctx.fillText(sat.name, x + 8, y - 6);
    });
  }, [
    dynamicSatPositions, 
    groundStations, 
    scenes, 
    activePasses, 
    selectedSatelliteId, 
    currentSimTime, 
    showSwaths, 
    showStationCones, 
    showTracks
  ]);

  // Click & Hover Handling
  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const w = canvasRef.current.width;
    const h = canvasRef.current.height;

    // Check satellites
    for (const sat of dynamicSatPositions) {
      const { x, y } = geoToCanvas(sat.currentLat, sat.currentLng, w, h);
      if (Math.hypot(mx - x, my - y) < 14) {
        setHoveredEntity({
          type: 'sat',
          title: sat.name,
          details: `Alt: ${sat.altitudeKm}km · Vel: ${sat.velocityKmS}km/s · Lat: ${sat.currentLat.toFixed(2)}°, Lng: ${sat.currentLng.toFixed(2)}°`,
          x: mx,
          y: my,
        });
        return;
      }
    }

    // Check stations
    for (const gs of groundStations) {
      const { x, y } = geoToCanvas(gs.lat, gs.lng, w, h);
      if (Math.hypot(mx - x, my - y) < 14) {
        setHoveredEntity({
          type: 'station',
          title: gs.name,
          details: `${gs.country} · Dishes: ${gs.dishes.length} · S/X/Ka Band`,
          x: mx,
          y: my,
        });
        return;
      }
    }

    // Check scenes
    for (const sc of scenes) {
      const { x, y } = geoToCanvas(sc.lat, sc.lng, w, h);
      if (Math.hypot(mx - x, my - y) < 14) {
        setHoveredEntity({
          type: 'scene',
          title: sc.title,
          details: `Domain: ${sc.domain.toUpperCase()} · Sensor: ${sc.sensor} · ${sc.locationName}`,
          x: mx,
          y: my,
        });
        return;
      }
    }

    setHoveredEntity(null);
  };

  const handleCanvasClick = (e: React.MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const w = canvasRef.current.width;
    const h = canvasRef.current.height;

    // Check satellites
    for (const sat of dynamicSatPositions) {
      const { x, y } = geoToCanvas(sat.currentLat, sat.currentLng, w, h);
      if (Math.hypot(mx - x, my - y) < 16) {
        onSelectSatellite(sat.id);
        return;
      }
    }

    // Check stations
    for (const gs of groundStations) {
      const { x, y } = geoToCanvas(gs.lat, gs.lng, w, h);
      if (Math.hypot(mx - x, my - y) < 16) {
        onSelectGroundStation(gs);
        return;
      }
    }

    // Check scenes
    for (const sc of scenes) {
      const { x, y } = geoToCanvas(sc.lat, sc.lng, w, h);
      if (Math.hypot(mx - x, my - y) < 16) {
        onSelectScene(sc);
        return;
      }
    }
  };

  return (
    <div className="relative w-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-2xl">
      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={1080}
        height={540}
        className="w-full h-[520px] block cursor-pointer"
        onMouseMove={handleCanvasMouseMove}
        onMouseLeave={() => setHoveredEntity(null)}
        onClick={handleCanvasClick}
      />

      {/* Top Left Header & Clock */}
      <div className="absolute top-3 left-3 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-lg p-3 text-xs shadow-xl flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="font-semibold text-slate-100 tracking-wide">ORBITAL OPERATIONS CONSOLE</span>
        </div>
        <div className="h-4 w-px bg-slate-800"></div>
        <div className="font-mono text-cyan-400 font-medium">
          {currentSimTime.toUTCString().replace('GMT', 'UTC')}
        </div>
      </div>

      {/* Top Right Simulation Speed & Layers */}
      <div className="absolute top-3 right-3 flex items-center gap-2">
        <div className="bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-lg p-1.5 flex items-center gap-1">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`p-1.5 rounded transition-colors ${isPlaying ? 'bg-slate-800 text-sky-400' : 'text-slate-400 hover:text-white'}`}
            title={isPlaying ? 'Pause Simulation' : 'Run Simulation'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setSimSpeed(1)}
            className={`px-2 py-1 text-[11px] font-mono rounded ${simSpeed === 1 ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40' : 'text-slate-400 hover:text-white'}`}
          >
            1x
          </button>
          <button
            onClick={() => setSimSpeed(10)}
            className={`px-2 py-1 text-[11px] font-mono rounded ${simSpeed === 10 ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40' : 'text-slate-400 hover:text-white'}`}
          >
            10x
          </button>
          <button
            onClick={() => setSimSpeed(60)}
            className={`px-2 py-1 text-[11px] font-mono rounded ${simSpeed === 60 ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40' : 'text-slate-400 hover:text-white'}`}
          >
            60x
          </button>
        </div>

        <div className="bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-lg p-1.5 flex items-center gap-1 text-[11px] font-mono">
          <button
            onClick={() => setShowTracks(!showTracks)}
            className={`px-2.5 py-1 rounded transition-colors ${showTracks ? 'bg-slate-800 text-slate-200' : 'text-slate-500'}`}
          >
            Tracks
          </button>
          <button
            onClick={() => setShowSwaths(!showSwaths)}
            className={`px-2.5 py-1 rounded transition-colors ${showSwaths ? 'bg-slate-800 text-slate-200' : 'text-slate-500'}`}
          >
            Swaths
          </button>
          <button
            onClick={() => setShowStationCones(!showStationCones)}
            className={`px-2.5 py-1 rounded transition-colors ${showStationCones ? 'bg-slate-800 text-slate-200' : 'text-slate-500'}`}
          >
            Ground Stations
          </button>
        </div>
      </div>

      {/* Bottom Floating Legend Bar */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="bg-slate-950/90 backdrop-blur-md border border-slate-800 rounded-lg px-3 py-2 text-[11px] flex items-center gap-4 pointer-events-auto">
          <span className="text-slate-400 font-medium">Domain Targets:</span>
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Agriculture
          </span>
          <span className="flex items-center gap-1.5 text-sky-400">
            <span className="w-2 h-2 rounded-full bg-sky-400"></span> Insurance (Flood/Loss)
          </span>
          <span className="flex items-center gap-1.5 text-rose-400">
            <span className="w-2 h-2 rounded-full bg-rose-400"></span> Defense & Maritime
          </span>
          <span className="flex items-center gap-1.5 text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span> Climate & Methane
          </span>
        </div>

        <div className="bg-slate-950/90 backdrop-blur border border-slate-800 rounded-lg px-3 py-2 text-[11px] font-mono text-slate-400">
          Click any Satellite, Station, or Target to inspect
        </div>
      </div>

      {/* Tooltip Hover Bubble */}
      {hoveredEntity && (
        <div
          className="absolute z-20 pointer-events-none bg-slate-900/95 backdrop-blur-md border border-sky-500/50 rounded-lg p-2.5 text-xs shadow-2xl"
          style={{
            left: Math.min(hoveredEntity.x + 12, 800),
            top: Math.min(hoveredEntity.y + 12, 450),
          }}
        >
          <div className="font-semibold text-slate-100 flex items-center gap-1.5">
            {hoveredEntity.type === 'sat' && <SatelliteIcon className="w-3.5 h-3.5 text-sky-400" />}
            {hoveredEntity.type === 'station' && <Radio className="w-3.5 h-3.5 text-emerald-400" />}
            {hoveredEntity.type === 'scene' && <MapPin className="w-3.5 h-3.5 text-amber-400" />}
            <span>{hoveredEntity.title}</span>
          </div>
          <div className="text-slate-400 font-mono text-[11px] mt-1">
            {hoveredEntity.details}
          </div>
        </div>
      )}
    </div>
  );
};

// Simplified continent vector silhouettes for equirectangular map projection
function drawSimplifiedWorldMap(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.fillStyle = '#162032'; // continent land fill
  ctx.strokeStyle = '#27364b'; // coastline border
  ctx.lineWidth = 1;

  // North America
  ctx.beginPath();
  ctx.moveTo(w * 0.08, h * 0.22);
  ctx.lineTo(w * 0.18, h * 0.18);
  ctx.lineTo(w * 0.28, h * 0.20);
  ctx.lineTo(w * 0.26, h * 0.38);
  ctx.lineTo(w * 0.22, h * 0.44);
  ctx.lineTo(w * 0.16, h * 0.42);
  ctx.lineTo(w * 0.12, h * 0.35);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // South America
  ctx.beginPath();
  ctx.moveTo(w * 0.23, h * 0.48);
  ctx.lineTo(w * 0.33, h * 0.52);
  ctx.lineTo(w * 0.35, h * 0.62);
  ctx.lineTo(w * 0.28, h * 0.82);
  ctx.lineTo(w * 0.25, h * 0.84);
  ctx.lineTo(w * 0.23, h * 0.60);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Europe
  ctx.beginPath();
  ctx.moveTo(w * 0.46, h * 0.18);
  ctx.lineTo(w * 0.55, h * 0.16);
  ctx.lineTo(w * 0.58, h * 0.30);
  ctx.lineTo(w * 0.48, h * 0.35);
  ctx.lineTo(w * 0.45, h * 0.28);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Africa
  ctx.beginPath();
  ctx.moveTo(w * 0.46, h * 0.38);
  ctx.lineTo(w * 0.58, h * 0.38);
  ctx.lineTo(w * 0.62, h * 0.52);
  ctx.lineTo(w * 0.56, h * 0.72);
  ctx.lineTo(w * 0.52, h * 0.72);
  ctx.lineTo(w * 0.46, h * 0.52);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Asia
  ctx.beginPath();
  ctx.moveTo(w * 0.58, h * 0.16);
  ctx.lineTo(w * 0.88, h * 0.16);
  ctx.lineTo(w * 0.85, h * 0.36);
  ctx.lineTo(w * 0.74, h * 0.48);
  ctx.lineTo(w * 0.66, h * 0.45);
  ctx.lineTo(w * 0.60, h * 0.32);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Australia
  ctx.beginPath();
  ctx.moveTo(w * 0.78, h * 0.62);
  ctx.lineTo(w * 0.88, h * 0.62);
  ctx.lineTo(w * 0.87, h * 0.76);
  ctx.lineTo(w * 0.77, h * 0.74);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Antarctica
  ctx.beginPath();
  ctx.moveTo(0, h * 0.94);
  ctx.lineTo(w, h * 0.94);
  ctx.lineTo(w, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fillStyle = '#1e293b';
  ctx.fill();
  ctx.stroke();
}

function drawTerminator(ctx: CanvasRenderingContext2D, w: number, h: number, time: Date) {
  // Approximate day/night solar line
  const utcHours = time.getUTCHours() + time.getUTCMinutes() / 60;
  // Subsolar point longitude: at 12:00 UTC, sun is at 0 deg lng
  const sunLng = (12 - utcHours) * 15;
  const sunX = ((sunLng + 180) / 360) * w;

  ctx.save();
  ctx.fillStyle = 'rgba(2, 6, 23, 0.45)'; // night shade
  ctx.beginPath();
  ctx.moveTo(0, 0);

  // Sinusoidal night boundary
  for (let x = 0; x <= w; x += 10) {
    const lng = (x / w) * 360 - 180;
    const relLngRad = ((lng - sunLng) * Math.PI) / 180;
    // Axial tilt ~23.4 degrees
    const yTerm = h * 0.5 + Math.sin(relLngRad) * h * 0.25;
    ctx.lineTo(x, yTerm);
  }

  ctx.lineTo(w, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
