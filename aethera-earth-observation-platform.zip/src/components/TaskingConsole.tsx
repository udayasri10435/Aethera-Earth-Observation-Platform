import React, { useState } from 'react';
import { TaskingRequest, SensorType, DomainType } from '../types/spaceData';
import { 
  Send, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Layers, 
  Zap, 
  ShieldAlert, 
  DollarSign, 
  Calendar,
  AlertCircle
} from 'lucide-react';

interface TaskingConsoleProps {
  taskings: TaskingRequest[];
  onAddTasking: (task: TaskingRequest) => void;
  onJumpToTarget?: (lat: number, lng: number) => void;
}

export const TaskingConsole: React.FC<TaskingConsoleProps> = ({
  taskings,
  onAddTasking,
  onJumpToTarget,
}) => {
  const [isOrdering, setIsOrdering] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const [customer, setCustomer] = useState<string>('Planetary Intelligence Group');
  const [domain, setDomain] = useState<DomainType>('defense');
  const [sensor, setSensor] = useState<SensorType>('sar_x_band');
  const [priority, setPriority] = useState<'routine' | 'priority_24h' | 'flash_charter_6h'>('priority_24h');
  const [targetLat, setTargetLat] = useState<number>(24.86);
  const [targetLng, setTargetLng] = useState<number>(67.00);
  const [targetName, setTargetName] = useState<string>('Port of Karachi Maritime Channel');
  const [orderSuccess, setOrderSuccess] = useState<boolean>(false);

  // Preset quick targets
  const quickTargets = [
    { name: 'Strait of Malacca Traffic', lat: 2.50, lng: 101.80, domain: 'defense' as DomainType, sensor: 'sar_x_band' as SensorType },
    { name: 'Valencia Albufera Basin', lat: 39.33, lng: -0.34, domain: 'insurance' as DomainType, sensor: 'sar_x_band' as SensorType },
    { name: 'Mato Grosso Soy Belt', lat: -12.50, lng: -55.70, domain: 'agriculture' as DomainType, sensor: 'optical_multispectral' as SensorType },
    { name: 'Nord Stream Trench Corridor', lat: 55.53, lng: 15.70, domain: 'defense' as DomainType, sensor: 'sar_l_band' as SensorType },
    { name: 'Turkmenistan Methane Craters', lat: 40.25, lng: 58.44, domain: 'climate' as DomainType, sensor: 'hyperspectral_tir' as SensorType },
  ];

  const handleSelectPreset = (tgt: typeof quickTargets[0]) => {
    setTargetName(tgt.name);
    setTargetLat(tgt.lat);
    setTargetLng(tgt.lng);
    setDomain(tgt.domain);
    setSensor(tgt.sensor);
  };

  const calculateCost = () => {
    let base = 800;
    if (sensor === 'sar_x_band') base = 1800;
    if (sensor === 'optical_ultra_hd') base = 1500;
    if (sensor === 'hyperspectral_tir') base = 2200;

    if (priority === 'priority_24h') base *= 1.6;
    if (priority === 'flash_charter_6h') base *= 2.5;
    return Math.round(base);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const newTask: TaskingRequest = {
      id: `task-${Date.now()}`,
      customer,
      title: title || `${targetName} Observation Task`,
      domain,
      sensor,
      priority,
      targetLat: Number(targetLat),
      targetLng: Number(targetLng),
      targetName,
      requestedDate: new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC',
      predictedPassUtc: priority === 'flash_charter_6h' ? 'Within 4h 18m' : 'Within 18h 40m',
      predictedDownlinkStation: 'Svalbard (SGS)',
      status: 'pending',
      costCredits: calculateCost(),
    };

    onAddTasking(newTask);
    setOrderSuccess(true);
    setTimeout(() => {
      setOrderSuccess(false);
      setIsOrdering(false);
      setTitle('');
    }, 1800);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <span>Constellation Tasking & Rapid Acquisition Hub</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Directly command spaceborne optical and synthetic aperture radar sensors for on-demand intelligence collection.
          </p>
        </div>

        <button
          onClick={() => setIsOrdering(!isOrdering)}
          className="flex items-center gap-2 py-2 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-lg text-xs transition-colors shadow-lg shadow-amber-500/10 cursor-pointer"
        >
          <Send className="w-4 h-4" />
          <span>{isOrdering ? 'Close Order Form' : 'New Acquisition Request'}</span>
        </button>
      </div>

      {/* New Order Drawer Form */}
      {isOrdering && (
        <form onSubmit={handleSubmitOrder} className="mt-6 p-5 bg-slate-950 border border-amber-500/30 rounded-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Configure Area of Interest (AOI) & Mission Payload
            </span>
            <span className="text-xs font-mono text-amber-400 font-semibold">
              Estimated Cost: {calculateCost().toLocaleString()} Credits
            </span>
          </div>

          {/* Quick Target Presets */}
          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1.5 uppercase">
              Quick Mission Presets
            </label>
            <div className="flex flex-wrap gap-2">
              {quickTargets.map((tgt) => (
                <button
                  type="button"
                  key={tgt.name}
                  onClick={() => handleSelectPreset(tgt)}
                  className={`text-xs px-2.5 py-1 rounded-md transition-colors border ${
                    targetName === tgt.name
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {tgt.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Target Name & Objective
              </label>
              <input
                type="text"
                value={targetName}
                onChange={(e) => setTargetName(e.target.value)}
                placeholder="e.g. Strait of Hormuz Tanker Surveillance"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Customer / Organization
              </label>
              <input
                type="text"
                value={customer}
                onChange={(e) => setCustomer(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Target Latitude (°N)
              </label>
              <input
                type="number"
                step="0.0001"
                value={targetLat}
                onChange={(e) => setTargetLat(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Target Longitude (°E)
              </label>
              <input
                type="number"
                step="0.0001"
                value={targetLng}
                onChange={(e) => setTargetLng(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Operational Domain
              </label>
              <select
                value={domain}
                onChange={(e) => setDomain(e.target.value as DomainType)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              >
                <option value="defense">Defense & Maritime</option>
                <option value="insurance">Insurance & Catastrophe</option>
                <option value="agriculture">Agriculture & Food Security</option>
                <option value="climate">Climate & Greenhouse Gases</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Sensor Payload Selection
              </label>
              <select
                value={sensor}
                onChange={(e) => setSensor(e.target.value as SensorType)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              >
                <option value="sar_x_band">Aether-SAR 1: X-band Radar (0.5m Spotlight, Cloud-Penetrating)</option>
                <option value="optical_ultra_hd">Aether-Optic 1: Ultra-HD Optical (0.3m Panchromatic & VNIR)</option>
                <option value="sar_l_band">Aether-SAR 2: L-band InSAR (Foliage & Glacial Deformation)</option>
                <option value="hyperspectral_tir">Aether-Enviro: Hyperspectral (240 bands) + Thermal IR</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Acquisition Priority Tier
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPriority('routine')}
                  className={`py-2 px-2 text-center rounded-lg text-xs font-medium transition-colors ${
                    priority === 'routine'
                      ? 'bg-slate-800 text-sky-400 border border-sky-400/50'
                      : 'bg-slate-900 text-slate-400 border border-slate-800'
                  }`}
                >
                  Routine (72h)
                </button>
                <button
                  type="button"
                  onClick={() => setPriority('priority_24h')}
                  className={`py-2 px-2 text-center rounded-lg text-xs font-medium transition-colors ${
                    priority === 'priority_24h'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 font-semibold'
                      : 'bg-slate-900 text-slate-400 border border-slate-800'
                  }`}
                >
                  Priority (24h)
                </button>
                <button
                  type="button"
                  onClick={() => setPriority('flash_charter_6h')}
                  className={`py-2 px-2 text-center rounded-lg text-xs font-medium transition-colors ${
                    priority === 'flash_charter_6h'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/50 font-bold'
                      : 'bg-slate-900 text-slate-400 border border-slate-800'
                  }`}
                >
                  Flash Disaster (6h)
                </button>
              </div>
            </div>
          </div>

          {orderSuccess ? (
            <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-lg text-xs text-emerald-300 flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Acquisition request submitted to orbit planner. Slew maneuver scheduled.</span>
            </div>
          ) : (
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsOrdering(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs transition-colors cursor-pointer"
              >
                Submit Acquisition Task ({calculateCost().toLocaleString()} Credits)
              </button>
            </div>
          )}
        </form>
      )}

      {/* Existing Tasking Orders Table */}
      <div className="mt-6 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 font-medium">
              <th className="pb-2">Mission Task & Target</th>
              <th className="pb-2">Customer</th>
              <th className="pb-2">Sensor</th>
              <th className="pb-2">Priority</th>
              <th className="pb-2">Pass Prediction</th>
              <th className="pb-2">Downlink Gateway</th>
              <th className="pb-2">Credits</th>
              <th className="pb-2">Pipeline Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850">
            {taskings.map((task) => (
              <tr key={task.id} className="hover:bg-slate-950/40 transition-colors">
                <td className="py-3">
                  <div className="font-semibold text-slate-200">{task.title}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    {task.targetLat.toFixed(2)}°N, {task.targetLng.toFixed(2)}°E · {task.targetName}
                  </div>
                </td>
                <td className="py-3 text-slate-300">{task.customer}</td>
                <td className="py-3 font-mono text-[11px] text-sky-400">
                  {task.sensor.replace(/_/g, ' ')}
                </td>
                <td className="py-3">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                      task.priority === 'flash_charter_6h'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : task.priority === 'priority_24h'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {task.priority.toUpperCase()}
                  </span>
                </td>
                <td className="py-3 font-mono text-slate-300 text-[11px]">
                  {task.predictedPassUtc}
                </td>
                <td className="py-3 text-slate-400 text-[11px] font-mono">
                  {task.predictedDownlinkStation}
                </td>
                <td className="py-3 font-mono text-amber-400 tabular-nums">
                  {task.costCredits.toLocaleString()}
                </td>
                <td className="py-3">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                      task.status === 'downlinked'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : task.status === 'acquired'
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {task.status.toUpperCase()}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
