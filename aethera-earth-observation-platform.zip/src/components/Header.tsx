import React, { useState, useEffect } from 'react';
import { 
  Globe2, 
  Satellite as SatelliteIcon, 
  Radio, 
  Eye, 
  BarChart3, 
  Zap, 
  ShieldAlert, 
  Clock, 
  Database,
  Search
} from 'lucide-react';

export type ActiveTab = 'studio' | 'orbit_map' | 'analytics' | 'ground_stations' | 'tasking';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  activeDownlinkCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  activeDownlinkCount,
}) => {
  const [utcTime, setUtcTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setUtcTime(
        now.toISOString().slice(11, 19) + ' UTC · ' + now.toISOString().slice(0, 10)
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="bg-slate-950 border-b border-slate-800/80 sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Operational Status */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-600 via-sky-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-sky-500/20">
                <Globe2 className="w-5 h-5 text-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-base tracking-wider text-slate-100 font-mono">
                    AETHERA
                  </span>
                  <span className="text-[11px] text-cyan-400 font-mono bg-cyan-950/70 border border-cyan-800/60 px-1.5 py-0.2 rounded">
                    SPACE DATA
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 leading-none mt-0.5">
                  Earth Observation · SAR Radar · Ground Segment
                </div>
              </div>
            </div>

            {/* Nav Tabs */}
            <nav className="hidden lg:flex items-center gap-1 ml-4 bg-slate-900/80 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => onSelectTab('studio')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  activeTab === 'studio'
                    ? 'bg-sky-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Imagery & SAR Studio</span>
              </button>

              <button
                onClick={() => onSelectTab('orbit_map')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  activeTab === 'orbit_map'
                    ? 'bg-sky-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Globe2 className="w-3.5 h-3.5" />
                <span>Tactical Orbit Map</span>
              </button>

              <button
                onClick={() => onSelectTab('analytics')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  activeTab === 'analytics'
                    ? 'bg-sky-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Domain Analytics</span>
              </button>

              <button
                onClick={() => onSelectTab('ground_stations')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  activeTab === 'ground_stations'
                    ? 'bg-sky-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Radio className="w-3.5 h-3.5" />
                <span>Ground Stations</span>
              </button>

              <button
                onClick={() => onSelectTab('tasking')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                  activeTab === 'tasking'
                    ? 'bg-sky-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Tasking Hub</span>
              </button>
            </nav>
          </div>

          {/* Right System Telemetry Indicators */}
          <div className="flex items-center gap-4 text-xs font-mono">
            {/* Live Clock */}
            <div className="hidden sm:flex items-center gap-1.5 text-slate-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>{utcTime}</span>
            </div>

            {/* Downlink Pulse */}
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
              <span className="text-slate-300">
                {activeDownlinkCount} ACTIVE DOWNLINK
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="lg:hidden flex items-center justify-around py-2 border-t border-slate-800/80 overflow-x-auto">
          <button
            onClick={() => onSelectTab('studio')}
            className={`px-2 py-1 text-xs whitespace-nowrap rounded ${
              activeTab === 'studio' ? 'text-sky-400 font-semibold' : 'text-slate-400'
            }`}
          >
            Imagery
          </button>
          <button
            onClick={() => onSelectTab('orbit_map')}
            className={`px-2 py-1 text-xs whitespace-nowrap rounded ${
              activeTab === 'orbit_map' ? 'text-sky-400 font-semibold' : 'text-slate-400'
            }`}
          >
            Orbits
          </button>
          <button
            onClick={() => onSelectTab('analytics')}
            className={`px-2 py-1 text-xs whitespace-nowrap rounded ${
              activeTab === 'analytics' ? 'text-sky-400 font-semibold' : 'text-slate-400'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => onSelectTab('ground_stations')}
            className={`px-2 py-1 text-xs whitespace-nowrap rounded ${
              activeTab === 'ground_stations' ? 'text-sky-400 font-semibold' : 'text-slate-400'
            }`}
          >
            Stations
          </button>
          <button
            onClick={() => onSelectTab('tasking')}
            className={`px-2 py-1 text-xs whitespace-nowrap rounded ${
              activeTab === 'tasking' ? 'text-sky-400 font-semibold' : 'text-slate-400'
            }`}
          >
            Tasking
          </button>
        </div>
      </div>
    </header>
  );
};
