import React, { useState } from 'react';
import { DomainType, EarthScene, TargetFeature } from '../types/spaceData';
import { 
  Sprout, 
  ShieldAlert, 
  Droplets, 
  Wind, 
  BarChart3, 
  TrendingUp, 
  FileText, 
  Download, 
  AlertCircle, 
  CheckCircle2, 
  Eye, 
  Crosshair,
  Compass,
  ArrowUpRight,
  Ship,
  Flame
} from 'lucide-react';

interface AnalyticsPanelProps {
  currentDomain: DomainType;
  onSelectDomain: (domain: DomainType) => void;
  scenes: EarthScene[];
  onSelectScene: (scene: EarthScene) => void;
}

export const AnalyticsPanel: React.FC<AnalyticsPanelProps> = ({
  currentDomain,
  onSelectDomain,
  scenes,
  onSelectScene,
}) => {
  const [downloadReportSuccess, setDownloadReportSuccess] = useState<string | null>(null);

  // Filter scenes for current domain
  const domainScenes = scenes.filter((s) => s.domain === currentDomain);
  const activeScene = domainScenes[0] || scenes[0];

  const handleExportIntelligenceBrief = () => {
    const reportData = {
      platform: 'Aethera Space Data Platform',
      domain: currentDomain.toUpperCase(),
      generatedAt: new Date().toISOString(),
      activeScene: {
        id: activeScene.id,
        title: activeScene.title,
        location: `${activeScene.locationName}, ${activeScene.country}`,
        sensor: activeScene.sensor,
        resolution: `${activeScene.resolutionM}m`,
        radiometrics: activeScene.radiometrics,
      },
      detections: activeScene.features,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aethera_${currentDomain}_intelligence_brief.json`;
    a.click();
    URL.revokeObjectURL(url);

    setDownloadReportSuccess('Intelligence brief successfully generated & exported.');
    setTimeout(() => setDownloadReportSuccess(null), 3500);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
      {/* Top Domain Switcher Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-sky-400" />
            <span>Multi-Spectral & Radar Domain Analytics</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Sensor fusion pipelines delivering calibrated planetary metrics for enterprise and defense missions.
          </p>
        </div>

        {/* Domain Segmented Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => onSelectDomain('agriculture')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              currentDomain === 'agriculture'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sprout className="w-3.5 h-3.5" />
            <span>Agriculture</span>
          </button>
          <button
            onClick={() => onSelectDomain('insurance')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              currentDomain === 'insurance'
                ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Droplets className="w-3.5 h-3.5" />
            <span>Insurance & Loss</span>
          </button>
          <button
            onClick={() => onSelectDomain('defense')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              currentDomain === 'defense'
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Defense & Maritime</span>
          </button>
          <button
            onClick={() => onSelectDomain('climate')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              currentDomain === 'climate'
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            <span>Climate & Emissions</span>
          </button>
        </div>
      </div>

      {/* Main Domain Analytics Content */}
      <div className="mt-6 space-y-6">
        {/* Domain KPI Score Cards */}
        {currentDomain === 'agriculture' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Mean Canopy NDVI</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">0.76</div>
              <div className="text-[11px] text-emerald-500/80 mt-1">Optimal chlorophyll absorption (+4.2% vs baseline)</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">SAR Volumetric Soil Moisture</div>
              <div className="text-2xl font-bold font-mono text-sky-400 mt-1 tabular-nums">26.4%</div>
              <div className="text-[11px] text-slate-400 mt-1">C-band dielectric permittivity probe</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Yield Forecast (Corn)</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1 tabular-nums">214 bu/ac</div>
              <div className="text-[11px] text-slate-400 mt-1">Confidence 94% across 240 parcels</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Nitrogen Deficit Flagged</div>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1 tabular-nums">18 Parcels</div>
              <div className="text-[11px] text-rose-400/80 mt-1">Variable rate prescription generated</div>
            </div>
          </div>
        )}

        {currentDomain === 'insurance' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Cloud Penetration Status</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">100% SAR</div>
              <div className="text-[11px] text-emerald-400 mt-1">X-band radar penetrated overcast storm</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Delineated Flood Extent</div>
              <div className="text-2xl font-bold font-mono text-sky-400 mt-1 tabular-nums">412.6 km²</div>
              <div className="text-[11px] text-sky-400 mt-1">Specular radar threshold: -24 dB</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Submerged Cadastral Structures</div>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1 tabular-nums">1,840 Units</div>
              <div className="text-[11px] text-slate-400 mt-1">Cross-referenced with land registry</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Automated Claim Clearance</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">82.5%</div>
              <div className="text-[11px] text-emerald-400 mt-1">Zero-fraud satellite loss verification</div>
            </div>
          </div>
        )}

        {currentDomain === 'defense' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Radar Targets Detected (CFAR)</div>
              <div className="text-2xl font-bold font-mono text-sky-400 mt-1 tabular-nums">19 Vessels</div>
              <div className="text-[11px] text-slate-400 mt-1">Spotlight 0.5m sub-meter resolution</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Dark Fleet (No AIS Beacon)</div>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1 tabular-nums">5 Vessels</div>
              <div className="text-[11px] text-rose-400 font-semibold mt-1">CRITICAL: Transponders disabled</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Max RCS Backscatter</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1 tabular-nums">+34.2 dBm²</div>
              <div className="text-[11px] text-slate-400 mt-1">Consistent with Guided Missile Destroyer</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Radar Wake Intercept Heading</div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">228° @ 18.4 kts</div>
              <div className="text-[11px] text-slate-400 mt-1">Kelvin wake divergence angle confirmed</div>
            </div>
          </div>
        )}

        {currentDomain === 'climate' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Super-Emitter Plume Flux</div>
              <div className="text-2xl font-bold font-mono text-rose-400 mt-1 tabular-nums">1,420 kg/hr</div>
              <div className="text-[11px] text-rose-400 font-semibold mt-1">Fugitive methane point source</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Absorption Band Ratio</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1 tabular-nums">2.3 µm SWIR</div>
              <div className="text-[11px] text-slate-400 mt-1">Hyperspectral 240-channel spectral depth</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Downwind Dispersion Plume</div>
              <div className="text-2xl font-bold font-mono text-sky-400 mt-1 tabular-nums">7.8 km</div>
              <div className="text-[11px] text-slate-400 mt-1">Boundary layer wind speed 4.2 m/s</div>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs text-slate-400">Glacial Rift Rate (Thwaites)</div>
              <div className="text-2xl font-bold font-mono text-purple-400 mt-1 tabular-nums">18.4 m/day</div>
              <div className="text-[11px] text-slate-400 mt-1">L-band repeat-pass DInSAR fringes</div>
            </div>
          </div>
        )}

        {/* Detailed Investigation Table & Scene Selector */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Detections & Feature Matrix */}
          <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-lg p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm font-semibold text-slate-200">
                Extracted Geospatial Features & Targets ({activeScene.features.length})
              </div>
              <div className="text-xs text-slate-400 font-mono">
                Scene: {activeScene.title.slice(0, 32)}...
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-medium">
                    <th className="pb-2">Target Feature</th>
                    <th className="pb-2">Classification</th>
                    <th className="pb-2">Confidence</th>
                    <th className="pb-2">Coordinates</th>
                    <th className="pb-2">Diagnostic Telemetry</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {activeScene.features.map((feat) => (
                    <tr key={feat.id} className="hover:bg-slate-900/50 transition-colors">
                      <td className="py-2.5 font-medium text-slate-200">
                        {feat.label}
                      </td>
                      <td className="py-2.5">
                        <span className="font-mono text-sky-400">{feat.type}</span>
                      </td>
                      <td className="py-2.5 font-mono text-emerald-400 tabular-nums">
                        {(feat.confidence * 100).toFixed(0)}%
                      </td>
                      <td className="py-2.5 font-mono text-slate-400 text-[11px] tabular-nums">
                        {feat.lat.toFixed(3)}°, {feat.lng.toFixed(3)}°
                      </td>
                      <td className="py-2.5 font-mono text-slate-300 text-[11px]">
                        {Object.entries(feat.metadata)
                          .map(([k, v]) => `${k}: ${v}`)
                          .join(' · ')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Col: Mission Intelligence Briefing & Export */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
            <div>
              <div className="text-sm font-semibold text-slate-200 flex items-center gap-2 mb-2">
                <FileText className="w-4 h-4 text-sky-400" />
                <span>Mission Intelligence Brief</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {activeScene.summary}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-850 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Sensor Platform:</span>
                  <span className="font-mono text-slate-200">{activeScene.sensor}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Ground Resolution:</span>
                  <span className="font-mono text-slate-200">{activeScene.resolutionM} meters</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Acquisition Date:</span>
                  <span className="font-mono text-slate-200">{activeScene.acquisitionDate}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Cloud Cover:</span>
                  <span className="font-mono text-slate-200">{activeScene.cloudCoverPercent}%</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800">
              <button
                onClick={handleExportIntelligenceBrief}
                className="w-full flex items-center justify-center gap-2 py-2 px-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold rounded-lg text-xs transition-colors shadow-lg shadow-sky-500/10 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Export Calibrated Intelligence Brief (JSON)</span>
              </button>

              {downloadReportSuccess && (
                <div className="mt-2 text-[11px] text-emerald-400 flex items-center gap-1.5 justify-center">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{downloadReportSuccess}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
